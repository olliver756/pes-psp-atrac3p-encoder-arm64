//! Ergonomic ATRAC1/ATRAC3/ATRAC3+ encoding and ATRAC1 decoding.
//!
//! `atracdenc` is the high-level facade over [`atracdenc_core`]. It owns the
//! common encode/decode orchestration, WAV/codec/container validation, and
//! container inference, exposing it all through two builders:
//! [`EncodeBuilder`] and [`DecodeBuilder`]. Most consumers want this crate;
//! reach for [`atracdenc_core`] directly only for low-level or advanced use.
//!
//! # Input constraints
//!
//! Encoding consumes **44100 Hz, 16-bit, mono or stereo** WAV. No resampling is
//! performed. Decoding is currently ATRAC1-only, from AEA input.
//!
//! # Encoding
//!
//! Build an [`EncodeBuilder`], point it at a WAV reader (or raw bytes), pick a
//! [`Codec`] and optionally a [`Container`] (otherwise inferred), then run.
//!
//! ```no_run
//! use atracdenc::{Codec, Container, EncodeBuilder, Result};
//!
//! fn main() -> Result<()> {
//!     let wav = std::fs::File::open("input.wav").unwrap();
//!     let out = std::fs::File::create("out.aea").unwrap();
//!     EncodeBuilder::new()
//!         .input_reader(wav)
//!         .output_writer(out)
//!         .codec(Codec::Atrac1)
//!         .container(Container::Aea)
//!         .run()?;
//!     Ok(())
//! }
//! ```
//!
//! Output can also be collected into a `Vec<u8>` instead of a writer:
//!
//! ```no_run
//! use atracdenc::{At3Settings, Codec, EncodeBuilder, Result};
//!
//! fn main() -> Result<()> {
//!     let bytes: Vec<u8> = EncodeBuilder::new()
//!         .input_bytes(std::fs::read("input.wav").unwrap())
//!         .codec(Codec::Atrac3) // OMA container inferred
//!         .at3_settings(At3Settings::default())
//!         .run_to_vec()?;
//!     println!("encoded {} bytes", bytes.len());
//!     Ok(())
//! }
//! ```
//!
//! # Decoding
//!
//! Decoding is ATRAC1-from-AEA only. The output is a 44100 Hz, 16-bit WAV.
//!
//! ```no_run
//! use atracdenc::{Codec, DecodeBuilder, Result};
//!
//! fn main() -> Result<()> {
//!     let wav: Vec<u8> = DecodeBuilder::new()
//!         .input_bytes(std::fs::read("input.aea").unwrap())
//!         .codec(Codec::Atrac1)
//!         .run_to_vec()?;
//!     std::fs::write("out.wav", wav).unwrap();
//!     Ok(())
//! }
//! ```
//!
//! # Codec-specific settings
//!
//! [`At1Settings`] and [`At3Settings`] carry the per-codec knobs (window mode,
//! bitrate, gain/tonal control, BFU allocation, Sony decode-delay alignment).
//! Settings that do not match the selected [`Codec`] are rejected at
//! [`EncodeBuilder::run`]/[`EncodeBuilder::run_to_vec`] time with
//! [`Error::InvalidInput`].

use std::{
    cell::RefCell,
    io::{self, Cursor, Read, Seek, SeekFrom, Write},
    rc::Rc,
};

use atracdenc_core::{
    AtracdencError,
    at1::{
        codec::{Atrac1Decoder, Atrac1Encoder},
        data::{EncodeSettings as CoreAt1Settings, WindowMode},
    },
    at3::{
        data::{
            BfuAllocMode as CoreBfuAllocMode, EncodeSettings as CoreAt3Settings, LP2, LP4,
            params_for_bitrate,
        },
        encoder::Atrac3Encoder,
    },
    at3p::encoder::{At3pEncoder, At3pSettings, parse_advanced_opt},
    container::{
        CompressedInput, CompressedOutput, ContainerError,
        aea::{AEA_FRAME_SIZE, AeaInput, AeaOutput},
        at3::At3Output,
        oma::{OmaChannelFormat, OmaCodec, OmaOutput},
        raw::RawOutput,
        rm::RmOutput,
    },
    pcm::{
        engine::{PcmBuffer, PcmEngine, PcmEngineError, PcmReader, Processor},
        wav::{WavReader, WavWriter},
    },
};
use log::{debug, info};

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("invalid input: {0}")]
    InvalidInput(String),
    #[error(transparent)]
    Core(#[from] AtracdencError),
    #[error(transparent)]
    Io(#[from] io::Error),
}

impl From<ContainerError> for Error {
    fn from(value: ContainerError) -> Self {
        Error::Core(AtracdencError::from(value))
    }
}

trait ReadSeek: Read + Seek {}

impl<T: Read + Seek> ReadSeek for T {}

trait WriteSeek: Write + Seek {}

impl<T: Write + Seek> WriteSeek for T {}

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum Codec {
    Atrac1,
    Atrac3,
    Atrac3Lp4,
    Atrac3plus,
}

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum Container {
    Aea,
    Oma,
    Riff,
    Rm,
    Raw,
}

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum At3BfuMode {
    Fast,
    Parity,
}

impl From<At3BfuMode> for CoreBfuAllocMode {
    fn from(value: At3BfuMode) -> Self {
        match value {
            At3BfuMode::Fast => CoreBfuAllocMode::Fast,
            At3BfuMode::Parity => CoreBfuAllocMode::Parity,
        }
    }
}

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub struct At1Settings {
    pub bfu_idx_const: u32,
    pub window_mode: At1WindowMode,
    pub window_mask: u32,
}

impl Default for At1Settings {
    fn default() -> Self {
        Self {
            bfu_idx_const: 0,
            window_mode: At1WindowMode::Auto,
            window_mask: 0,
        }
    }
}

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum At1WindowMode {
    Auto,
    NoTransient,
}

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub struct At3Settings {
    pub bitrate_kbps: Option<u32>,
    pub no_gain_control: bool,
    pub no_tonal_components: bool,
    pub bfu_idx_const: u32,
    pub bfu_mode: At3BfuMode,
    pub bfu_idx_fast: bool,
    /// When set, align the encoded ATRAC3 stream so that Sony's reference
    /// decoder (e.g. MiniDisc hardware / at3tool) reproduces the original
    /// PCM with zero sample delay and exact length. Currently supported only
    /// for ATRAC3 LP2 stereo into a RIFF/AT3 container.
    pub sony_delay_align: bool,
}

impl Default for At3Settings {
    fn default() -> Self {
        Self {
            bitrate_kbps: None,
            no_gain_control: false,
            no_tonal_components: false,
            bfu_idx_const: 0,
            bfu_mode: At3BfuMode::Fast,
            bfu_idx_fast: false,
            sony_delay_align: false,
        }
    }
}

pub struct EncodeBuilder {
    input: Option<EncodeInput>,
    output: Option<EncodeOutput>,
    codec: Codec,
    container: Option<Container>,
    at1: At1Settings,
    at3: At3Settings,
    at3p_frame_size: u16,
    yaml_log: Option<Box<dyn Write>>,
    advanced: Option<String>,
}

enum EncodeInput {
    Reader(Box<dyn Read>),
}

enum EncodeOutput {
    Writer(Box<dyn WriteSeek>),
    Vec,
}

impl Default for EncodeBuilder {
    fn default() -> Self {
        Self::new()
    }
}

impl EncodeBuilder {
    pub fn new() -> Self {
        Self {
            input: None,
            output: None,
            codec: Codec::Atrac1,
            container: None,
            at1: At1Settings::default(),
            at3: At3Settings::default(),
            at3p_frame_size: 2048,
            yaml_log: None,
            advanced: None,
        }
    }

    pub fn input_reader<R: Read + 'static>(mut self, reader: R) -> Self {
        self.input = Some(EncodeInput::Reader(Box::new(reader)));
        self
    }

    pub fn input_bytes(self, bytes: impl Into<Vec<u8>>) -> Self {
        self.input_reader(Cursor::new(bytes.into()))
    }

    pub fn output_writer<W: Write + Seek + 'static>(mut self, writer: W) -> Self {
        self.output = Some(EncodeOutput::Writer(Box::new(writer)));
        self
    }

    pub fn codec(mut self, codec: Codec) -> Self {
        self.codec = codec;
        self
    }

    pub fn container(mut self, container: Container) -> Self {
        self.container = Some(container);
        self
    }

    pub fn at1_settings(mut self, settings: At1Settings) -> Self {
        self.at1 = settings;
        self
    }

    pub fn at3_settings(mut self, settings: At3Settings) -> Self {
        self.at3 = settings;
        self
    }

    pub fn yaml_log_writer<W: Write + 'static>(mut self, writer: W) -> Self {
        self.yaml_log = Some(Box::new(writer));
        self
    }

    /// ATRAC3+ `--advanced` option string (e.g. `ghadbg=5`).
    pub fn advanced(mut self, advanced: impl Into<String>) -> Self {
        self.advanced = Some(advanced.into());
        self
    }

    /// Select the experimental 192-byte mono ATRAC3+ frame profile observed in PES PSP IDs.
    /// Compatibility with the console must be verified before replacing original game audio.
    pub fn psp_atrac3plus_192_mono(mut self) -> Self {
        self.at3p_frame_size = 192;
        self
    }

    pub fn run(self) -> Result<()> {
        encode(self).map(|_| ())
    }

    pub fn run_to_vec(mut self) -> Result<Vec<u8>> {
        self.output = Some(EncodeOutput::Vec);
        encode(self).and_then(|output| match output {
            EncodedOutput::Vec(bytes) => Ok(bytes),
            EncodedOutput::Sink => Err(invalid_input("internal error: expected byte output")),
        })
    }
}

pub struct DecodeBuilder {
    input: Option<DecodeInput>,
    output: Option<DecodeOutput>,
    codec: Codec,
    container: Option<Container>,
}

enum DecodeInput {
    Reader(Box<dyn ReadSeek>),
}

enum DecodeOutput {
    Writer(Box<dyn WriteSeek>),
    Vec,
}

impl Default for DecodeBuilder {
    fn default() -> Self {
        Self::new()
    }
}

impl DecodeBuilder {
    pub fn new() -> Self {
        Self {
            input: None,
            output: None,
            codec: Codec::Atrac1,
            container: None,
        }
    }

    pub fn input_reader<R: Read + Seek + 'static>(mut self, reader: R) -> Self {
        self.input = Some(DecodeInput::Reader(Box::new(reader)));
        self
    }

    pub fn input_bytes(self, bytes: impl Into<Vec<u8>>) -> Self {
        self.input_reader(Cursor::new(bytes.into()))
    }

    pub fn output_writer<W: Write + Seek + 'static>(mut self, writer: W) -> Self {
        self.output = Some(DecodeOutput::Writer(Box::new(writer)));
        self
    }

    pub fn codec(mut self, codec: Codec) -> Self {
        self.codec = codec;
        self
    }

    pub fn container(mut self, container: Container) -> Self {
        self.container = Some(container);
        self
    }

    pub fn run(self) -> Result<()> {
        decode(self).map(|_| ())
    }

    pub fn run_to_vec(mut self) -> Result<Vec<u8>> {
        self.output = Some(DecodeOutput::Vec);
        decode(self).and_then(|output| match output {
            DecodedOutput::Vec(bytes) => Ok(bytes),
            DecodedOutput::Sink => Err(invalid_input("internal error: expected byte output")),
        })
    }
}

enum EncodedOutput {
    Sink,
    Vec(Vec<u8>),
}

enum DecodedOutput {
    Sink,
    Vec(Vec<u8>),
}

fn encode(mut builder: EncodeBuilder) -> Result<EncodedOutput> {
    validate_encode_settings(&builder)?;
    let input = builder
        .input
        .take()
        .ok_or_else(|| invalid_input("missing input file"))?;
    let reader = open_wav_reader(input)?;
    let channels = usize::from(reader.channels());
    let sample_rate = reader.sample_rate();
    let bits_per_sample = reader.bits_per_sample();
    let total_samples = reader.total_samples();

    validate_wav(&reader)?;
    debug!(
        "validated WAV input: channels={channels}, sample_rate={sample_rate}, bits_per_sample={bits_per_sample}, total_samples={total_samples}"
    );
    let mut frame_count = encoded_frame_count(total_samples, builder.codec)?;

    let output = builder
        .output
        .take()
        .ok_or_else(|| invalid_input("missing output file"))?;
    let container = match (builder.container, &output) {
        (Some(container), _) => container,
        (None, EncodeOutput::Writer(_) | EncodeOutput::Vec) => default_container(builder.codec),
    };
    validate_container(builder.codec, container)?;

    // Sony decode-delay alignment (opt-in, ATRAC3 LP2/LP4 stereo + RIFF only).
    // Codec/bitrate (LP2 or LP4) are already validated in
    // validate_encode_settings; here we additionally require the runtime-resolved
    // container and channel count. Reverse-engineered from psp_at3tool.exe: the
    // ATRAC3 encoder delay is 69 samples (0x45) and Sony's decoder trims
    // 1024 + 69 = 1093 samples (verified for both LP2 and LP4).
    let align =
        matches!(builder.codec, Codec::Atrac3 | Codec::Atrac3Lp4) && builder.at3.sony_delay_align;
    let mut fact_samples: Option<u32> = None;
    if align {
        if container != Container::Riff {
            return Err(invalid_input(
                "--sony-delay-align is only supported with the riff/at3 container",
            ));
        }
        if channels != 2 {
            return Err(invalid_input(
                "--sony-delay-align is only supported for stereo ATRAC3 (LP2/LP4)",
            ));
        }
        let aligned_frames = total_samples
            .saturating_add(u64::from(ATRAC3_DECODER_DELAY))
            .div_ceil(ATRAC3_FRAME_SAMPLES);
        frame_count = u32::try_from(aligned_frames)
            .map_err(|_| invalid_input("input is too long for container metadata"))?;
        fact_samples = Some(
            u32::try_from(total_samples)
                .map_err(|_| invalid_input("input is too long for container metadata"))?,
        );
    }
    debug!(
        "selected encode container: codec={}, container={}, frame_count={frame_count}",
        codec_name(builder.codec),
        container_name(container)
    );

    log_encode_summary(
        builder.codec,
        container,
        channels,
        sample_rate,
        total_samples,
        frame_count,
    );

    let mut vec_output = None;
    let mut processor = match output {
        EncodeOutput::Writer(writer) => build_seek_encoder(
            &mut builder,
            writer,
            container,
            channels,
            sample_rate,
            frame_count,
            fact_samples,
        )?,
        EncodeOutput::Vec => {
            let shared = SharedCursor::default();
            vec_output = Some(shared.clone());
            build_seek_encoder(
                &mut builder,
                shared,
                container,
                channels,
                sample_rate,
                frame_count,
                fact_samples,
            )?
        }
    };
    let pcm_reader: Box<dyn PcmReader> = if align {
        Box::new(AlignedReader::new(
            reader,
            channels,
            ATRAC3_FRAME_SAMPLES as usize,
            ATRAC3_ENCODER_DELAY as usize,
            frame_count,
        ))
    } else {
        Box::new(reader)
    };
    let mut engine = PcmEngine::new(
        frame_samples(builder.codec),
        channels,
        Some(pcm_reader),
        None,
    );
    let mut progress = ProgressLogger::new(total_samples);
    progress.record(0);

    loop {
        match engine.apply_process(frame_samples(builder.codec), processor.as_mut()) {
            Ok(processed) => progress.record(processed),
            Err(AtracdencError::PcmEngine(PcmEngineError::NoDataToRead)) => break,
            Err(err) => return Err(err.into()),
        }
    }
    progress.finish();
    drop(processor);

    if let Some(output) = vec_output {
        Ok(EncodedOutput::Vec(output.into_bytes()))
    } else {
        Ok(EncodedOutput::Sink)
    }
}

fn decode(mut builder: DecodeBuilder) -> Result<DecodedOutput> {
    if builder.codec != Codec::Atrac1 {
        return Err(invalid_input("decode is only supported for atrac1"));
    }
    if builder
        .container
        .is_some_and(|container| container != Container::Aea)
    {
        return Err(invalid_input("decode is only supported from AEA input"));
    }

    let input = builder
        .input
        .take()
        .ok_or_else(|| invalid_input("missing input file"))?;
    let output = builder
        .output
        .take()
        .ok_or_else(|| invalid_input("missing output file"))?;
    let input = open_aea_input(input)?;
    let channels = input.channels().max(1);
    const DECODE_BUFFER_SAMPLES: usize = 4096;
    let total_samples = input.length_in_samples();
    debug!(
        "opened AEA input: name={}, channels={channels}, frame_size={}, total_samples={total_samples}",
        input.name(),
        input.frame_size()
    );
    log_decode_summary(input.name(), channels, total_samples);

    let mut vec_output = None;
    let writer: Box<dyn atracdenc_core::pcm::engine::PcmWriter> = match output {
        DecodeOutput::Writer(writer) => Box::new(
            WavWriter::new(writer, channels as u16, 44_100)
                .map_err(|e| invalid_input(e.to_string()))?,
        ),
        DecodeOutput::Vec => {
            let shared = SharedCursor::default();
            vec_output = Some(shared.clone());
            Box::new(
                WavWriter::new(shared, channels as u16, 44_100)
                    .map_err(|e| invalid_input(e.to_string()))?,
            )
        }
    };
    let mut engine = PcmEngine::new(DECODE_BUFFER_SAMPLES, channels, None, Some(writer));
    let mut decoder = Atrac1Decoder::new(Box::new(input));

    let mut processed = 0_u64;
    let mut progress = ProgressLogger::new(total_samples);
    progress.record(0);
    while total_samples > processed {
        match engine.apply_process(atracdenc_core::at1::data::NUM_SAMPLES, &mut decoder) {
            Ok(p) => {
                processed = p;
                progress.record(processed);
            }
            Err(err) => return Err(err.into()),
        }
    }
    progress.finish();

    drop(engine);

    if let Some(output) = vec_output {
        Ok(DecodedOutput::Vec(output.into_bytes()))
    } else {
        Ok(DecodedOutput::Sink)
    }
}

fn open_wav_reader(input: EncodeInput) -> Result<WavReader<Box<dyn Read>>> {
    match input {
        EncodeInput::Reader(reader) => WavReader::new(reader)
            .map_err(|e| invalid_input(format!("unable to read WAV input: {e}"))),
    }
}

fn open_aea_input(input: DecodeInput) -> Result<AeaInput<Box<dyn ReadSeek>>> {
    match input {
        DecodeInput::Reader(reader) => Ok(AeaInput::new(reader)?),
    }
}

/// ATRAC3 codec constants reverse-engineered from Sony's psp_at3tool.exe.
/// `FUN_004039e0` returns 0x45 (69) as the ATRAC3 encoder delay, and the
/// reference decoder trims one frame plus that delay (1024 + 69 = 1093).
const ATRAC3_FRAME_SAMPLES: u64 = 1024;
const ATRAC3_ENCODER_DELAY: u32 = 69;
const ATRAC3_DECODER_DELAY: u32 = 1024 + ATRAC3_ENCODER_DELAY;

/// PCM reader adapter for Sony decode-delay alignment. It advances the input
/// by `skip_per_ch` samples (the encoder delay) so the decoded output lines up
/// at lag 0, and feeds exactly `target_frames` frames (zero-padding the tail)
/// so the decoder's trim never clips real audio.
struct AlignedReader<R: PcmReader> {
    inner: R,
    channels: usize,
    frame_samples: usize,
    skip_left: usize,
    served_frames: u32,
    target_frames: u32,
    scratch: PcmBuffer,
    carry: std::collections::VecDeque<f32>,
    inner_eof: bool,
}

impl<R: PcmReader> AlignedReader<R> {
    fn new(
        inner: R,
        channels: usize,
        frame_samples: usize,
        skip_per_ch: usize,
        target_frames: u32,
    ) -> Self {
        Self {
            inner,
            channels,
            frame_samples,
            skip_left: skip_per_ch * channels,
            served_frames: 0,
            target_frames,
            scratch: PcmBuffer::new(frame_samples, channels),
            carry: std::collections::VecDeque::new(),
            inner_eof: false,
        }
    }

    fn refill(&mut self) -> std::result::Result<(), AtracdencError> {
        if self.inner_eof {
            return Ok(());
        }
        let ok = self
            .inner
            .read(&mut self.scratch, self.frame_samples as u32)?;
        if !ok {
            self.inner_eof = true;
            return Ok(());
        }
        let samples = self.scratch.samples();
        let mut start = 0;
        if self.skip_left > 0 {
            let drop = self.skip_left.min(samples.len());
            self.skip_left -= drop;
            start = drop;
        }
        self.carry.extend(samples[start..].iter().copied());
        Ok(())
    }

    fn next_sample(&mut self) -> std::result::Result<f32, AtracdencError> {
        loop {
            if let Some(s) = self.carry.pop_front() {
                return Ok(s);
            }
            if self.inner_eof {
                return Ok(0.0);
            }
            self.refill()?;
        }
    }
}

impl<R: PcmReader> PcmReader for AlignedReader<R> {
    fn read(
        &mut self,
        data: &mut PcmBuffer,
        size: u32,
    ) -> std::result::Result<bool, AtracdencError> {
        if self.served_frames >= self.target_frames {
            return Ok(false);
        }
        let need = size as usize * self.channels;
        for slot in &mut data.samples_mut()[..need] {
            *slot = self.next_sample()?;
        }
        self.served_frames += 1;
        Ok(true)
    }
}

fn build_seek_encoder<W>(
    builder: &mut EncodeBuilder,
    output: W,
    container: Container,
    channels: usize,
    sample_rate: u32,
    frame_count: u32,
    fact_samples: Option<u32>,
) -> Result<Box<dyn Processor>>
where
    W: Write + Seek + 'static,
{
    match builder.codec {
        Codec::Atrac1 => {
            debug!(
                "building ATRAC1 encoder: container={}, channels={channels}, frame_count={frame_count}",
                container_name(container)
            );
            build_atrac1_encoder(
                builder,
                build_atrac1_output(output, container, channels, frame_count)?,
            )
        }
        Codec::Atrac3 | Codec::Atrac3Lp4 => {
            let settings = build_atrac3_settings(builder, channels)?;
            info!(
                "ATRAC3 settings: bitrate={} bps, frame_size={} bytes, joint_stereo={}",
                settings.container_params.bitrate,
                settings.container_params.frame_sz,
                settings.container_params.joint_stereo
            );
            debug!(
                "building ATRAC3 encoder: container={}, channels={channels}, sample_rate={sample_rate}, frame_count={frame_count}, no_gain_control={}, no_tonal_components={}, bfu_idx_const={}, bfu_mode={:?}",
                container_name(container),
                settings.no_gain_control,
                settings.no_tonal_components,
                settings.bfu_idx_const,
                settings.bfu_alloc_mode
            );
            let output = build_atrac3_output(
                output,
                container,
                channels,
                sample_rate,
                frame_count,
                settings,
                fact_samples,
            )?;
            build_atrac3_encoder(output, settings, builder.yaml_log.take())
        }
        Codec::Atrac3plus => {
            let mut settings = At3pSettings::default();
            settings.frame_size = builder.at3p_frame_size;
            if settings.frame_size == 192 && channels != 1 {
                return Err(invalid_input("the 192-byte PSP ATRAC3+ profile requires mono input"));
            }
            parse_advanced_opt(builder.advanced.as_deref(), &mut settings)?;
            debug!(
                "building ATRAC3plus encoder: container={}, channels={channels}, sample_rate={sample_rate}, frame_count={frame_count}, use_gha={}",
                container_name(container),
                settings.use_gha
            );
            let output = build_atrac3plus_output(
                output, container, channels, sample_rate, frame_count,
                u32::from(settings.frame_size),
            )?;
            Ok(Box::new(At3pEncoder::new(output, channels, settings)))
        }
    }
}

fn build_atrac1_encoder(
    builder: &EncodeBuilder,
    output: Box<dyn CompressedOutput>,
) -> Result<Box<dyn Processor>> {
    let window_mode = match builder.at1.window_mode {
        At1WindowMode::Auto => WindowMode::Auto,
        At1WindowMode::NoTransient => WindowMode::NoTransient,
    };
    let settings = CoreAt1Settings::new(
        builder.at1.bfu_idx_const,
        window_mode,
        builder.at1.window_mask,
    )?;
    Ok(Box::new(Atrac1Encoder::try_new(output, settings)?))
}

fn build_atrac3_encoder(
    output: Box<dyn CompressedOutput>,
    settings: CoreAt3Settings,
    yaml_log: Option<Box<dyn Write>>,
) -> Result<Box<dyn Processor>> {
    Ok(Box::new(Atrac3Encoder::with_yaml_log(
        output, settings, yaml_log,
    )))
}

fn build_atrac3_settings(builder: &EncodeBuilder, channels: usize) -> Result<CoreAt3Settings> {
    let bitrate = resolve_atrac3_bitrate(builder.codec, builder.at3.bitrate_kbps);
    let mut settings = CoreAt3Settings::new(
        bitrate,
        builder.at3.no_gain_control,
        builder.at3.no_tonal_components,
        channels as u8,
        builder.at3.bfu_idx_const,
    )
    .ok_or_else(|| invalid_input("unsupported ATRAC3 bitrate"))?;
    settings.bfu_alloc_mode = builder.at3.bfu_mode.into();
    Ok(settings)
}

/// Resolve the requested ATRAC3 bitrate (in bps) the same way for validation and
/// encoding: `Codec::Atrac3Lp4` defaults to the LP4 rate, otherwise the kbps
/// request (or 0 for "default", which `params_for_bitrate` maps to LP2).
fn resolve_atrac3_bitrate(codec: Codec, bitrate_kbps: Option<u32>) -> u32 {
    match (codec, bitrate_kbps) {
        (Codec::Atrac3Lp4, None) => LP4.bitrate,
        (_, bitrate) => bitrate.unwrap_or(0).saturating_mul(1024),
    }
}

fn build_atrac1_output<W>(
    output: W,
    container: Container,
    channels: usize,
    frame_count: u32,
) -> Result<Box<dyn CompressedOutput>>
where
    W: Write + Seek + 'static,
{
    match container {
        Container::Aea => Ok(Box::new(AeaOutput::new(
            output,
            "atracdenc-rust",
            channels,
            frame_count,
        )?)),
        Container::Raw => Ok(Box::new(RawOutput::new(
            output,
            channels,
            Some(AEA_FRAME_SIZE),
        ))),
        _ => unreachable!("ATRAC1 container validity checked earlier"),
    }
}

fn build_atrac3_output<W>(
    output: W,
    container: Container,
    channels: usize,
    sample_rate: u32,
    frame_count: u32,
    settings: CoreAt3Settings,
    fact_samples: Option<u32>,
) -> Result<Box<dyn CompressedOutput>>
where
    W: Write + Seek + 'static,
{
    let params = settings.container_params;
    match container {
        Container::Oma => {
            let channel_format = if params.joint_stereo {
                OmaChannelFormat::StereoJoint
            } else {
                OmaChannelFormat::Stereo
            };
            Ok(Box::new(OmaOutput::new(
                output,
                OmaCodec::Atrac3,
                sample_rate,
                channel_format,
                params.frame_sz as u32,
            )?))
        }
        Container::Riff => {
            let mut riff = At3Output::atrac3(
                output,
                2,
                frame_count,
                params.frame_sz as u32,
                params.joint_stereo,
            )?;
            if let Some(samples) = fact_samples {
                riff.set_fact_samples(samples);
            }
            Ok(Box::new(riff))
        }
        Container::Rm => Ok(Box::new(RmOutput::new(
            output,
            channels,
            frame_count,
            params.frame_sz as u32,
            params.joint_stereo,
        )?)),
        Container::Raw => Ok(Box::new(RawOutput::new(
            output,
            channels,
            Some(params.frame_sz as usize),
        ))),
        _ => unreachable!("ATRAC3 container validity checked earlier"),
    }
}

fn build_atrac3plus_output<W>(
    output: W,
    container: Container,
    channels: usize,
    sample_rate: u32,
    frame_count: u32,
    frame_size: u32,
) -> Result<Box<dyn CompressedOutput>>
where
    W: Write + Seek + 'static,
{
    match container {
        Container::Oma => {
            let channel_format = if channels == 1 {
                OmaChannelFormat::Mono
            } else {
                OmaChannelFormat::Stereo
            };
            Ok(Box::new(OmaOutput::new(
                output,
                OmaCodec::Atrac3Plus,
                sample_rate,
                channel_format,
                frame_size,
            )?))
        }
        Container::Riff => Ok(Box::new(At3Output::atrac3plus(
            output,
            channels,
            frame_count,
            frame_size,
        )?)),
        Container::Raw => Ok(Box::new(RawOutput::new(
            output,
            channels,
            Some(frame_size as usize),
        ))),
        _ => unreachable!("ATRAC3plus container validity checked earlier"),
    }
}

fn validate_encode_settings(builder: &EncodeBuilder) -> Result<()> {
    if builder.codec != Codec::Atrac1 && builder.at1.window_mode == At1WindowMode::NoTransient {
        return Err(invalid_input("--notransient is only supported for atrac1"));
    }
    if !matches!(builder.codec, Codec::Atrac3 | Codec::Atrac3Lp4) && builder.yaml_log.is_some() {
        return Err(invalid_input("--yaml-log is only supported for ATRAC3"));
    }
    if !matches!(builder.codec, Codec::Atrac3 | Codec::Atrac3Lp4)
        && (builder.at3.no_gain_control || builder.at3.no_tonal_components)
    {
        return Err(invalid_input(
            "--nogaincontrol and --notonal are only supported for atrac3",
        ));
    }
    if !matches!(builder.codec, Codec::Atrac3 | Codec::Atrac3Lp4)
        && builder.at3.bfu_mode != At3BfuMode::Fast
    {
        return Err(invalid_input("--at3-bfu-mode is only supported for atrac3"));
    }
    if !matches!(builder.codec, Codec::Atrac3 | Codec::Atrac3Lp4) && builder.at3.bfu_idx_fast {
        return Err(invalid_input("--bfuidxfast is only supported for atrac3"));
    }
    if matches!(builder.codec, Codec::Atrac3plus)
        && (builder.at1.bfu_idx_const != 0 || builder.at3.bfu_idx_const != 0)
    {
        return Err(invalid_input(
            "--bfuidxconst is not supported for atrac3plus",
        ));
    }
    if builder.codec != Codec::Atrac3plus && builder.advanced.is_some() {
        return Err(invalid_input("--advanced is only supported for atrac3plus"));
    }
    if !matches!(builder.codec, Codec::Atrac3 | Codec::Atrac3Lp4)
        && builder.at3.bitrate_kbps.is_some()
    {
        return Err(invalid_input("--bitrate is only supported for atrac3"));
    }
    if let Some(bitrate) = builder.at3.bitrate_kbps
        && !(32..=384).contains(&bitrate)
    {
        return Err(invalid_input("--bitrate must be in the range 32..384"));
    }
    if builder.at3.bfu_idx_fast && builder.at3.bfu_mode == At3BfuMode::Parity {
        return Err(invalid_input(
            "--bfuidxfast cannot be combined with --at3-bfu-mode parity",
        ));
    }
    if builder.at3.sony_delay_align {
        // The 69-sample ATRAC3 encoder delay is a QMF group delay, identical
        // across frame formats. Sony's decoder only accepts the standard MiniDisc
        // modes though, so alignment is supported for LP2 and LP4 (both verified
        // against at3tool); other bitrates are rejected rather than silently
        // producing unaligned (and often un-decodable) output.
        if !matches!(builder.codec, Codec::Atrac3 | Codec::Atrac3Lp4) {
            return Err(invalid_input(
                "--sony-delay-align is only supported for atrac3 lp2/lp4",
            ));
        }
        let params = params_for_bitrate(resolve_atrac3_bitrate(
            builder.codec,
            builder.at3.bitrate_kbps,
        ));
        if params != Some(LP2) && params != Some(LP4) {
            return Err(invalid_input(
                "--sony-delay-align is only supported for atrac3 lp2/lp4 (omit --bitrate)",
            ));
        }
    }
    if builder.codec == Codec::Atrac1
        && builder.at1.bfu_idx_const > atracdenc_core::at1::data::MAX_BFU_IDX_CONST
    {
        // Surface the core invariant early (before opening the WAV) using the
        // canonical core error so the limit has a single source of truth.
        CoreAt1Settings::new(
            builder.at1.bfu_idx_const,
            WindowMode::Auto,
            builder.at1.window_mask,
        )?;
    }
    Ok(())
}

fn validate_wav<R: Read>(reader: &WavReader<R>) -> Result<()> {
    let channels = reader.channels();
    if channels == 0 || channels > 2 {
        return Err(invalid_input(
            "only mono and stereo WAV input is currently supported",
        ));
    }
    if reader.sample_rate() != 44_100 {
        return Err(invalid_input(
            "unsupported sample rate: only 44100 Hz is supported",
        ));
    }
    if reader.bits_per_sample() != 16 {
        return Err(invalid_input(
            "unsupported WAV format: only 16-bit PCM is supported",
        ));
    }
    Ok(())
}

pub fn validate_container(codec: Codec, container: Container) -> Result<()> {
    let supported = match codec {
        Codec::Atrac1 => matches!(container, Container::Aea | Container::Raw),
        Codec::Atrac3 | Codec::Atrac3Lp4 => {
            matches!(
                container,
                Container::Oma | Container::Riff | Container::Rm | Container::Raw
            )
        }
        Codec::Atrac3plus => matches!(container, Container::Oma | Container::Riff | Container::Raw),
    };

    if supported {
        Ok(())
    } else {
        Err(invalid_input(format!(
            "container {} is not supported for {}",
            container_name(container),
            codec_name(codec)
        )))
    }
}

fn default_container(codec: Codec) -> Container {
    match codec {
        Codec::Atrac1 => Container::Aea,
        Codec::Atrac3 | Codec::Atrac3Lp4 | Codec::Atrac3plus => Container::Oma,
    }
}

fn encoded_frame_count(total_samples: u64, codec: Codec) -> Result<u32> {
    let frames = total_samples.div_ceil(frame_samples(codec) as u64);
    u32::try_from(frames).map_err(|_| invalid_input("input is too long for container metadata"))
}

fn frame_samples(codec: Codec) -> usize {
    match codec {
        Codec::Atrac1 => atracdenc_core::at1::data::NUM_SAMPLES,
        Codec::Atrac3 | Codec::Atrac3Lp4 => atracdenc_core::at3::data::NUM_SAMPLES,
        Codec::Atrac3plus => 2048,
    }
}

struct ProgressLogger {
    total: u64,
    last_percent: Option<u64>,
}

impl ProgressLogger {
    fn new(total: u64) -> Self {
        Self {
            total,
            last_percent: None,
        }
    }

    fn record(&mut self, processed: u64) {
        if self.total == 0 {
            return;
        }

        let percent = processed.min(self.total) * 100 / self.total;
        if self.last_percent != Some(percent) {
            info!("Progress: {percent}% done");
            self.last_percent = Some(percent);
        }
    }

    fn finish(&mut self) {
        self.record(self.total);
        info!("Done");
    }
}

fn log_encode_summary(
    codec: Codec,
    container: Container,
    channels: usize,
    sample_rate: u32,
    total_samples: u64,
    frame_count: u32,
) {
    info!("Input:");
    info!("  Channels: {channels}");
    info!("  Sample rate: {sample_rate} Hz");
    info!(
        "  Duration: {:.3} sec",
        duration_seconds(total_samples, sample_rate)
    );
    info!("Output:");
    info!("  Codec: {}", codec_label(codec));
    info!("  Container: {}", container_label(container));
    info!("  Frames: {frame_count}");
}

fn log_decode_summary(name: &str, channels: usize, total_samples: u64) {
    info!("Input:");
    info!("  Name: {name}");
    info!("  Container: AEA");
    info!("  Channels: {channels}");
    info!(
        "  Duration: {:.3} sec",
        duration_seconds(total_samples, 44_100)
    );
    info!("Output:");
    info!("  Codec: PCM");
    info!("  Sample rate: 44100 Hz");
}

fn duration_seconds(total_samples: u64, sample_rate: u32) -> f64 {
    if sample_rate == 0 {
        0.0
    } else {
        total_samples as f64 / f64::from(sample_rate)
    }
}

fn codec_label(codec: Codec) -> &'static str {
    match codec {
        Codec::Atrac1 => "ATRAC1",
        Codec::Atrac3 => "ATRAC3",
        Codec::Atrac3Lp4 => "ATRAC3 LP4",
        Codec::Atrac3plus => "ATRAC3plus",
    }
}

fn container_label(container: Container) -> &'static str {
    match container {
        Container::Aea => "AEA",
        Container::Oma => "OMA",
        Container::Riff => "RIFF",
        Container::Rm => "RM",
        Container::Raw => "Raw",
    }
}

fn codec_name(codec: Codec) -> &'static str {
    match codec {
        Codec::Atrac1 => "atrac1",
        Codec::Atrac3 => "atrac3",
        Codec::Atrac3Lp4 => "atrac3_lp4",
        Codec::Atrac3plus => "atrac3plus",
    }
}

fn container_name(container: Container) -> &'static str {
    match container {
        Container::Aea => "aea",
        Container::Oma => "oma",
        Container::Riff => "riff",
        Container::Rm => "rm",
        Container::Raw => "raw",
    }
}

fn invalid_input(message: impl Into<String>) -> Error {
    Error::InvalidInput(message.into())
}

#[derive(Clone, Default)]
struct SharedCursor {
    inner: Rc<RefCell<Cursor<Vec<u8>>>>,
}

impl SharedCursor {
    fn into_bytes(self) -> Vec<u8> {
        self.inner.borrow().get_ref().clone()
    }
}

impl Write for SharedCursor {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.inner.borrow_mut().write(buf)
    }

    fn flush(&mut self) -> io::Result<()> {
        self.inner.borrow_mut().flush()
    }
}

impl Seek for SharedCursor {
    fn seek(&mut self, pos: SeekFrom) -> io::Result<u64> {
        self.inner.borrow_mut().seek(pos)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn wav_bytes(frames: usize) -> Vec<u8> {
        let mut bytes = Vec::new();
        let data_len = frames as u32 * 2;
        bytes.extend_from_slice(b"RIFF");
        bytes.extend_from_slice(&(36 + data_len).to_le_bytes());
        bytes.extend_from_slice(b"WAVEfmt ");
        bytes.extend_from_slice(&16_u32.to_le_bytes());
        bytes.extend_from_slice(&1_u16.to_le_bytes());
        bytes.extend_from_slice(&1_u16.to_le_bytes());
        bytes.extend_from_slice(&44_100_u32.to_le_bytes());
        bytes.extend_from_slice(&(44_100_u32 * 2).to_le_bytes());
        bytes.extend_from_slice(&2_u16.to_le_bytes());
        bytes.extend_from_slice(&16_u16.to_le_bytes());
        bytes.extend_from_slice(b"data");
        bytes.extend_from_slice(&data_len.to_le_bytes());
        for i in 0..frames {
            let phase = 2.0 * std::f64::consts::PI * 440.0 * i as f64 / 44_100.0;
            let sample = (phase.sin() * 8000.0) as i16;
            bytes.extend_from_slice(&sample.to_le_bytes());
        }
        bytes
    }

    #[test]
    fn validates_codec_container_matrix() {
        assert!(validate_container(Codec::Atrac1, Container::Aea).is_ok());
        assert!(validate_container(Codec::Atrac1, Container::Raw).is_ok());
        assert!(validate_container(Codec::Atrac3, Container::Rm).is_ok());
        assert_eq!(
            "invalid input: container oma is not supported for atrac1",
            validate_container(Codec::Atrac1, Container::Oma)
                .unwrap_err()
                .to_string()
        );
    }

    #[test]
    fn rejects_invalid_atrac1_bfu_idx_const() {
        let err = EncodeBuilder::new()
            .input_bytes(wav_bytes(1024))
            .container(Container::Aea)
            .at1_settings(At1Settings {
                bfu_idx_const: 9,
                ..At1Settings::default()
            })
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: bfu_idx_const must be in the range 0..=8 for atrac1",
            err.to_string()
        );
    }

    #[test]
    fn encodes_atrac1_from_bytes_to_vec() {
        let bytes = EncodeBuilder::new()
            .input_bytes(wav_bytes(8192))
            .codec(Codec::Atrac1)
            .container(Container::Aea)
            .run_to_vec()
            .unwrap();
        assert_eq!(&[0x00, 0x08, 0x00, 0x00], &bytes[..4]);
        assert!(bytes.len() > AEA_FRAME_SIZE);
    }

    #[test]
    fn encodes_atrac1_from_reader_to_vec() {
        let bytes = EncodeBuilder::new()
            .input_reader(Cursor::new(wav_bytes(8192)))
            .codec(Codec::Atrac1)
            .container(Container::Aea)
            .run_to_vec()
            .unwrap();
        assert_eq!(&[0x00, 0x08, 0x00, 0x00], &bytes[..4]);
        assert!(bytes.len() > AEA_FRAME_SIZE);
    }

    #[test]
    fn encodes_atrac1_to_writer_with_default_container() {
        let output = SharedCursor::default();
        EncodeBuilder::new()
            .input_bytes(wav_bytes(8192))
            .codec(Codec::Atrac1)
            .output_writer(output.clone())
            .run()
            .unwrap();

        let bytes = output.into_bytes();
        assert_eq!(&[0x00, 0x08, 0x00, 0x00], &bytes[..4]);
        assert!(bytes.len() > AEA_FRAME_SIZE);
    }

    #[test]
    fn encodes_atrac3_to_vec() {
        let bytes = EncodeBuilder::new()
            .input_bytes(wav_bytes(2048))
            .codec(Codec::Atrac3)
            .container(Container::Oma)
            .at3_settings(At3Settings {
                no_tonal_components: true,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap();
        assert_eq!(b"EA3", &bytes[..3]);
        assert!(bytes.len() > 96);
    }

    #[test]
    fn encodes_atrac3_to_vec_with_default_container() {
        let bytes = EncodeBuilder::new()
            .input_bytes(wav_bytes(2048))
            .codec(Codec::Atrac3)
            .at3_settings(At3Settings {
                no_tonal_components: true,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap();
        assert_eq!(b"EA3", &bytes[..3]);
        assert!(bytes.len() > 96);
    }

    #[test]
    fn rejects_advanced_for_non_atrac3plus() {
        let err = EncodeBuilder::new()
            .codec(Codec::Atrac3)
            .advanced("ghadbg=0")
            .run_to_vec()
            .unwrap_err();

        assert_eq!(
            "invalid input: --advanced is only supported for atrac3plus",
            err.to_string()
        );
    }

    #[test]
    fn encodes_atrac3plus_psp_192_mono_riff() {
        let bytes = EncodeBuilder::new()
            .input_bytes(wav_bytes(4096))
            .codec(Codec::Atrac3plus)
            .container(Container::Riff)
            .psp_atrac3plus_192_mono()
            .run_to_vec()
            .unwrap();

        // ATRAC3+ RIFF header is 80 bytes; every encoded frame must be 192 bytes.
        assert_eq!(b"RIFF", &bytes[..4]);
        assert_eq!(b"WAVE", &bytes[8..12]);
        assert_eq!(192, u16::from_le_bytes(bytes[32..34].try_into().unwrap()));
        let data_size = u32::from_le_bytes(bytes[76..80].try_into().unwrap());
        assert!(data_size > 0);
        assert_eq!(0, data_size % 192);
        assert_eq!(80 + data_size as usize, bytes.len());
    }

    #[test]
    fn psp_192_mono_profile_rejects_stereo_input() {
        let err = EncodeBuilder::new()
            .input_bytes(wav_bytes_stereo(4096))
            .codec(Codec::Atrac3plus)
            .container(Container::Riff)
            .psp_atrac3plus_192_mono()
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: the 192-byte PSP ATRAC3+ profile requires mono input",
            err.to_string()
        );
    }

    #[test]
    fn rejects_ignored_atrac3_options_for_atrac3plus() {
        let err = EncodeBuilder::new()
            .codec(Codec::Atrac3plus)
            .yaml_log_writer(Vec::new())
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: --yaml-log is only supported for ATRAC3",
            err.to_string()
        );

        let err = EncodeBuilder::new()
            .codec(Codec::Atrac3plus)
            .at3_settings(At3Settings {
                no_gain_control: true,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: --nogaincontrol and --notonal are only supported for atrac3",
            err.to_string()
        );

        let err = EncodeBuilder::new()
            .codec(Codec::Atrac3plus)
            .at3_settings(At3Settings {
                bfu_mode: At3BfuMode::Parity,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: --at3-bfu-mode is only supported for atrac3",
            err.to_string()
        );

        let err = EncodeBuilder::new()
            .codec(Codec::Atrac3plus)
            .at3_settings(At3Settings {
                bfu_idx_fast: true,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: --bfuidxfast is only supported for atrac3",
            err.to_string()
        );

        let err = EncodeBuilder::new()
            .codec(Codec::Atrac3plus)
            .at3_settings(At3Settings {
                bfu_idx_const: 1,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: --bfuidxconst is not supported for atrac3plus",
            err.to_string()
        );
    }

    #[test]
    fn decodes_atrac1_from_bytes_to_wav_vec() {
        let encoded = EncodeBuilder::new()
            .input_bytes(wav_bytes(8192))
            .codec(Codec::Atrac1)
            .container(Container::Aea)
            .run_to_vec()
            .unwrap();

        let decoded = DecodeBuilder::new()
            .codec(Codec::Atrac1)
            .input_bytes(encoded)
            .run_to_vec()
            .unwrap();

        assert_eq!(b"RIFF", &decoded[..4]);
        assert_eq!(b"WAVE", &decoded[8..12]);
    }

    #[test]
    fn run_requires_explicit_writer_output() {
        let err = EncodeBuilder::new()
            .input_bytes(wav_bytes(8192))
            .codec(Codec::Atrac1)
            .container(Container::Aea)
            .run()
            .unwrap_err();

        assert_eq!("invalid input: missing output file", err.to_string());
    }

    fn wav_bytes_stereo(frames: usize) -> Vec<u8> {
        let mut bytes = Vec::new();
        let data_len = frames as u32 * 2 * 2; // 2 channels, 16-bit
        bytes.extend_from_slice(b"RIFF");
        bytes.extend_from_slice(&(36 + data_len).to_le_bytes());
        bytes.extend_from_slice(b"WAVEfmt ");
        bytes.extend_from_slice(&16_u32.to_le_bytes());
        bytes.extend_from_slice(&1_u16.to_le_bytes());
        bytes.extend_from_slice(&2_u16.to_le_bytes());
        bytes.extend_from_slice(&44_100_u32.to_le_bytes());
        bytes.extend_from_slice(&(44_100_u32 * 4).to_le_bytes());
        bytes.extend_from_slice(&4_u16.to_le_bytes());
        bytes.extend_from_slice(&16_u16.to_le_bytes());
        bytes.extend_from_slice(b"data");
        bytes.extend_from_slice(&data_len.to_le_bytes());
        for i in 0..frames {
            let phase = 2.0 * std::f64::consts::PI * 440.0 * i as f64 / 44_100.0;
            let sample = (phase.sin() * 8000.0) as i16;
            bytes.extend_from_slice(&sample.to_le_bytes());
            bytes.extend_from_slice(&sample.to_le_bytes());
        }
        bytes
    }

    #[test]
    fn sony_delay_align_sets_fact_to_true_samples_and_flush_frame_count() {
        let total_samples: usize = 5000; // not frame-aligned
        let bytes = EncodeBuilder::new()
            .input_bytes(wav_bytes_stereo(total_samples))
            .codec(Codec::Atrac3)
            .container(Container::Riff)
            .at3_settings(At3Settings {
                sony_delay_align: true,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap();

        // fact (per-channel sample count) lives at offset 60 in the AT3 header.
        let fact = u32::from_le_bytes(bytes[60..64].try_into().unwrap());
        assert_eq!(
            fact, total_samples as u32,
            "fact must equal true sample count"
        );

        // data chunk size at offset 72; frames = data / frame_sz (LP2 = 384).
        let data_size = u32::from_le_bytes(bytes[72..76].try_into().unwrap());
        let frames = data_size / 384;
        let expected = ((total_samples as u64 + 1093).div_ceil(1024)) as u32;
        assert_eq!(
            frames, expected,
            "frame count must include the codec-delay flush"
        );
    }

    #[test]
    fn sony_delay_align_rejects_mono() {
        let err = EncodeBuilder::new()
            .input_bytes(wav_bytes(2048))
            .codec(Codec::Atrac3)
            .container(Container::Riff)
            .at3_settings(At3Settings {
                sony_delay_align: true,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: --sony-delay-align is only supported for stereo ATRAC3 (LP2/LP4)",
            err.to_string()
        );
    }

    #[test]
    fn sony_delay_align_rejects_non_riff_container() {
        let err = EncodeBuilder::new()
            .input_bytes(wav_bytes_stereo(2048))
            .codec(Codec::Atrac3)
            .container(Container::Oma)
            .at3_settings(At3Settings {
                sony_delay_align: true,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: --sony-delay-align is only supported with the riff/at3 container",
            err.to_string()
        );
    }

    #[test]
    fn sony_delay_align_rejects_non_atrac3_codec() {
        for codec in [Codec::Atrac1, Codec::Atrac3plus] {
            let err = EncodeBuilder::new()
                .input_bytes(wav_bytes_stereo(2048))
                .codec(codec)
                .container(Container::Riff)
                .at3_settings(At3Settings {
                    sony_delay_align: true,
                    ..At3Settings::default()
                })
                .run_to_vec()
                .unwrap_err();
            assert_eq!(
                "invalid input: --sony-delay-align is only supported for atrac3 lp2/lp4",
                err.to_string(),
                "codec {codec:?} should reject sony_delay_align"
            );
        }
    }

    #[test]
    fn sony_delay_align_lp4_sets_fact_and_flush_frame_count() {
        let total_samples: usize = 5000; // not frame-aligned
        let bytes = EncodeBuilder::new()
            .input_bytes(wav_bytes_stereo(total_samples))
            .codec(Codec::Atrac3Lp4)
            .container(Container::Riff)
            .at3_settings(At3Settings {
                sony_delay_align: true,
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap();

        // LP4 frame size is 192 bytes; fact still carries the true sample count.
        let fact = u32::from_le_bytes(bytes[60..64].try_into().unwrap());
        assert_eq!(fact, total_samples as u32);
        let data_size = u32::from_le_bytes(bytes[72..76].try_into().unwrap());
        let frames = data_size / 192;
        let expected = ((total_samples as u64 + 1093).div_ceil(1024)) as u32;
        assert_eq!(frames, expected, "LP4 uses the same codec-delay flush");
    }

    #[test]
    fn sony_delay_align_rejects_non_lp2_lp4_bitrate() {
        let err = EncodeBuilder::new()
            .input_bytes(wav_bytes_stereo(2048))
            .codec(Codec::Atrac3)
            .container(Container::Riff)
            .at3_settings(At3Settings {
                sony_delay_align: true,
                bitrate_kbps: Some(192),
                ..At3Settings::default()
            })
            .run_to_vec()
            .unwrap_err();
        assert_eq!(
            "invalid input: --sony-delay-align is only supported for atrac3 lp2/lp4 (omit --bitrate)",
            err.to_string()
        );
    }
}


// ---- Minimal C ABI for Android JNI integration (PSP 192-byte mono profile) ----
use std::ffi::c_char;
use std::panic::{catch_unwind, AssertUnwindSafe};

/// Encodes a complete 44.1 kHz / 16-bit / mono WAV into experimental
/// ATRAC3+ RIFF using 192-byte frames. Output memory must be released with
/// `atracdenc_psp192_free`.
#[unsafe(no_mangle)]
pub extern "C" fn atracdenc_psp192_encode(
    wav_ptr: *const u8,
    wav_len: usize,
    out_ptr: *mut *mut u8,
    out_len: *mut usize,
    err_ptr: *mut c_char,
    err_cap: usize,
) -> i32 {
    if wav_ptr.is_null() || out_ptr.is_null() || out_len.is_null() || wav_len == 0 {
        return -1;
    }
    unsafe {
        *out_ptr = std::ptr::null_mut();
        *out_len = 0;
    }
    let result = catch_unwind(AssertUnwindSafe(|| {
        let wav = unsafe { std::slice::from_raw_parts(wav_ptr, wav_len) };
        EncodeBuilder::new()
            .input_bytes(wav.to_vec())
            .codec(Codec::Atrac3plus)
            .container(Container::Riff)
            .psp_atrac3plus_192_mono()
            .run_to_vec()
    }));
    match result {
        Ok(Ok(bytes)) => {
            let boxed = bytes.into_boxed_slice();
            let len = boxed.len();
            let ptr = Box::into_raw(boxed) as *mut u8;
            unsafe {
                *out_ptr = ptr;
                *out_len = len;
            }
            0
        }
        Ok(Err(e)) => {
            write_ffi_error(err_ptr, err_cap, &e.to_string());
            -2
        }
        Err(_) => {
            write_ffi_error(err_ptr, err_cap, "encoder panic");
            -3
        }
    }
}

/// Releases an output buffer returned by `atracdenc_psp192_encode`.
#[unsafe(no_mangle)]
pub extern "C" fn atracdenc_psp192_free(ptr: *mut u8, len: usize) {
    if !ptr.is_null() {
        unsafe {
            let slice = std::ptr::slice_from_raw_parts_mut(ptr, len);
            drop(Box::from_raw(slice));
        }
    }
}

fn write_ffi_error(dst: *mut c_char, cap: usize, message: &str) {
    if dst.is_null() || cap == 0 { return; }
    let bytes = message.as_bytes();
    let count = bytes.len().min(cap - 1);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), dst as *mut u8, count);
        *(dst.add(count)) = 0;
    }
}
