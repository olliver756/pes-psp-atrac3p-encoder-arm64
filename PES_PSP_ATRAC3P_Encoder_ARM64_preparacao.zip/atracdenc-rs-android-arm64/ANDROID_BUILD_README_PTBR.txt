PES PSP AUDIO EDITOR - COMPILACAO DO ENCODER ATRAC3+ PARA ANDROID ARM64

ESTADO DESTA ENTREGA
- Codigo-fonte preparado para compilacao automatizada no GitHub Actions.
- Perfil experimental: ATRAC3+ mono, 44.100 Hz, PCM WAV 16-bit, frames de 192 bytes.
- A biblioteca .so NAO foi compilada neste ambiente.
- Ainda NAO foi comprovado que o bitstream gerado e aceito pelo PES PSP.

O QUE ESTA INCLUIDO
1. Codigo-fonte atracdenc-rs com o perfil experimental de 192 bytes.
2. Interface C ABI e ponte JNI para Android.
3. Workflow .github/workflows/android-arm64.yml para compilar com Rust stable e Android NDK r27c.
4. Classe Java NativeAtrac.java, ainda isolada e nao chamada pela MainActivity.
5. Projeto PES PSP Audio Editor estavel separado, sem alteracoes na reproducao/exportacao.

COMO GERAR A BIBLIOTECA
1. Extraia a pasta atracdenc-rs-android-arm64.
2. Crie um repositorio GitHub vazio e envie TODO o conteudo dessa pasta para a raiz do repositorio.
3. No GitHub, abra Actions.
4. Selecione "Build ATRAC3+ encoder for Android ARM64".
5. Toque em Run workflow.
6. Aguarde o workflow terminar. Se falhar, abra o job e copie o primeiro erro de compilacao/linkagem.
7. Em Artifacts, baixe atrac-encoder-android-arm64.

INTEGRACAO NO APKBUILDER (SOMENTE DEPOIS DO TESTE)
- Coloque libatrac_encoder.so em lib/arm64-v8a/ na raiz do projeto ApkBuilder.
- Adicione NativeAtrac.java ao pacote com.olliver.pespspudioeditor.
- NAO chame NativeAtrac ainda antes de validar a saida em arquivo ID descartavel.
- Nao substitua os IDs originais; trabalhe sempre com copias.

VALIDACAO OBRIGATORIA ANTES DA INTEGRACAO
1. Codificar um WAV exportado pelo proprio aplicativo.
2. Verificar se a saida contem frames alinhados de 192 bytes e se a estrutura RIFF esta coerente.
3. Decodificar a saida com uma ferramenta independente e comparar duracao/amostras.
4. Inserir em uma COPIA de ID PES PSP usando PesAtrac3pId.
5. Testar a copia no emulador/PSP e confirmar reproducao real no jogo.

OBSERVACOES
- O tamanho de 192 bytes foi observado nos IDs analisados, mas isso sozinho nao prova compatibilidade do encoder.
- A contagem de amostras deve considerar atraso e padding do encoder; nao deve ser estimada sem medicao.
- A classe PesAtrac3pId continua isolada. Ela nao codifica audio e nao foi conectada a interface.
- A versao estavel do app foi mantida separada e nao deve ser sobrescrita por este experimento.
