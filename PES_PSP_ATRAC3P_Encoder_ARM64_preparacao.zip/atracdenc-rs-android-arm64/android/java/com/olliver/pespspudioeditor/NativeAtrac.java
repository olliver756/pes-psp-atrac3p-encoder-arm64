package com.olliver.pespspudioeditor;

/** JNI bridge for the experimental PES PSP ATRAC3+ 192-byte mono encoder. */
public final class NativeAtrac {
    static {
        System.loadLibrary("atrac_encoder");
    }

    private NativeAtrac() {}

    /**
     * Encodes a complete 44.1 kHz, 16-bit, mono PCM WAV to ATRAC3+ RIFF.
     * Throws IllegalArgumentException if the input/profile is unsupported.
     */
    public static native byte[] encodeWav(byte[] wavBytes);
}
