# Alocação adaptativa de bits — ATRAC3+ estéreo/280 bytes

## Problema observado

O perfil de 280 bytes estava usando a tabela fixa `ALLOC_TABLE` herdada do perfil de quadros grandes. Quando a soma dos dados ultrapassava o orçamento do quadro, `TonalComponentEncoder::check_frame_done` reduzia `num_quant_units` sucessivamente (32 → 28 → ...). No arquivo produzido para o PES PSP, isso fazia a maior parte dos quadros sair com apenas 6–9 unidades de quantização, embora o ID original use 26 unidades em todos os quadros analisados. A redução de unidades cortava as bandas superiores e deixava a música abafada.

## Alteração desta revisão

A mudança é isolada ao perfil com `frame_sz == 280` e dois canais:

1. Inicia cada quadro com 26 unidades de quantização, igual ao perfil observado no `ID00055` original.
2. Começa com word length 7 em cada unidade/canal.
3. Mede, por unidade, o tamanho exato da codificação espectral atual e o tamanho ao reduzir um nível de word length.
4. Calcula a penalidade de distorção relativa no domínio espectral, usando o fator de escala do bloco e a tabela de mantissas ATRAC3+.
5. Reduz primeiro os níveis com menor aumento de distorção por bit economizado; aplica uma pequena proteção às bandas superiores para não descartar o brilho antes das bandas inferiores.
6. Recalcula o quadro até caber no orçamento. Somente como último recurso reduz a unidade de maior frequência; se não couber nem com o mínimo previsto, retorna erro em vez de escrever um quadro maior que o permitido.

Os perfis que não são estéreo/280 continuam usando a alocação anterior. A rotina de contêiner WAV/ID, `fact`, `OFFSET`, JNI e a ponte Java não foram modificadas nesta revisão.

## Testes adicionados

- A configuração adaptativa mantém 26 QUs no perfil estéreo/280.
- A configuração preserva as word lengths entre as repetições de controle de taxa, em vez de restaurar a tabela fixa.
- A medida de distorção confirma que a quantização mais grosseira não tem erro inferior à quantização fina no vetor de teste.

## Validação ainda necessária

Esta revisão é uma alteração no código-fonte. O ambiente em que foi preparada não possui `cargo`/`rustc`, então a suíte Rust e a compilação ARM64 ainda precisam ser executadas no GitHub Actions (Rust 1.96.0 + Android NDK r27c). Depois da compilação:

1. Gerar um WAV ATRAC3+ estéreo/280 com `Castle of Glass`.
2. Confirmar que o tamanho de cada quadro é 280 bytes e que o cabeçalho reporta 26 QUs na maior parte dos quadros; conferir a distribuição completa, pois o fallback pode reduzir QUs em quadros extremos.
3. Decodificar o WAV gerado com FFmpeg e comparar o PCM decodificado com o PCM de entrada, alinhando o atraso do codec antes de calcular SNR.
4. Recriar o ID mantendo a correção FACT/OFFSET já validada e testar no PES 14 PSP.
5. Comparar a qualidade no jogo com a versão anterior.

A decodificação pelo FFmpeg não substitui o teste no jogo. Esta revisão ainda não está validada no PSP.
