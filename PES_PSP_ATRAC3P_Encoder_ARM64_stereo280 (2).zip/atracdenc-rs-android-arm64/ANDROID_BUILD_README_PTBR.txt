PES PSP AUDIO EDITOR - COMPILACAO DO ENCODER ATRAC3+ PARA ANDROID ARM64

ESTADO DESTA ENTREGA
- Codigo-fonte preparado para compilacao automatizada no GitHub Actions.
- Perfil experimental A: ATRAC3+ mono, 44.100 Hz, PCM WAV 16-bit, frames de 192 bytes.
- Perfil experimental B: ATRAC3+ stereo, 44.100 Hz, PCM WAV 16-bit, frames de 280 bytes.
- A compatibilidade dos dois perfis com o jogo ainda precisa ser comprovada em testes no PSP.

O QUE ESTA INCLUIDO
1. Codigo-fonte atracdenc-rs com os perfis experimentais mono/192 e stereo/280.
2. Interface C ABI e ponte JNI com encodeWav() e encodeWavStereo().
3. Workflow .github/workflows/android-arm64.yml para compilar ARM64 com Rust 1.96.0 e Android NDK r27c.
4. Classe Java NativeAtrac.java isolada, ainda nao ligada a interface estavel do app.
5. Projeto PES PSP Audio Editor estavel separado, sem alteracoes na reproducao/exportacao.

VALIDACAO
- Os testes unitarios verificam a saida RIFF, os canais e o alinhamento de frames de cada perfil.
- A compilacao da biblioteca nao comprova, por si so, que o PSP aceita os bitstreams.
- Antes de substituir um ID, decodifique a saida com ferramenta independente e teste uma copia do ID no jogo.
- Preserve o cabecalho e os campos fact originais que nao forem especificamente recalculados.
- Nao estime o numero de amostras apenas pelo numero de frames: avalie atraso/padding com o WAV de referencia.
