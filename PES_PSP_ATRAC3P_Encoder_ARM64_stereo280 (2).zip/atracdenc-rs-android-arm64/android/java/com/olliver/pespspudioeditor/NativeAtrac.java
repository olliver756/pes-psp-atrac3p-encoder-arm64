package com.olliver.pespspudioeditor;

/** JNI bridge for experimental PES PSP ATRAC3+ mono/stereo encoder profiles. */
public final class NativeAtrac {
    static {
        System.loadLibrary("atrac_encoder");
    }

    private NativeAtrac() {}

    /** Encodes a complete 44.1 kHz, 16-bit, mono PCM WAV to 192-byte ATRAC3+ frames. */
    public static native byte[] encodeWav(byte[] wavBytes);

    /** Encodes a complete 44.1 kHz, 16-bit, stereo PCM WAV to 280-byte ATRAC3+ frames. */
    public static native byte[] encodeWavStereo(byte[] wavBytes);
}
