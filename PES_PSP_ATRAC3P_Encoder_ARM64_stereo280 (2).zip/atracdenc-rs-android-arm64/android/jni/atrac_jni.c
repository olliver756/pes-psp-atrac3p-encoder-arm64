#include <jni.h>
#include <stdint.h>
#include <stdlib.h>

int32_t atracdenc_psp192_encode(const uint8_t *wav, size_t wav_len,
                                uint8_t **out, size_t *out_len,
                                char *err, size_t err_cap);
int32_t atracdenc_psp280_encode(const uint8_t *wav, size_t wav_len,
                                uint8_t **out, size_t *out_len,
                                char *err, size_t err_cap);
void atracdenc_psp_free(uint8_t *ptr, size_t len);

typedef int32_t (*atrac_encode_fn)(const uint8_t *, size_t, uint8_t **,
                                   size_t *, char *, size_t);

static jbyteArray encode_wav(JNIEnv *env, jbyteArray input, atrac_encode_fn encode) {
    if (input == NULL) return NULL;
    jsize input_len = (*env)->GetArrayLength(env, input);
    jbyte *input_bytes = (*env)->GetByteArrayElements(env, input, NULL);
    if (input_bytes == NULL) return NULL;

    uint8_t *encoded = NULL;
    size_t encoded_len = 0;
    char error[512] = {0};
    int32_t status = encode((const uint8_t *)input_bytes, (size_t)input_len,
                            &encoded, &encoded_len, error, sizeof(error));
    (*env)->ReleaseByteArrayElements(env, input, input_bytes, JNI_ABORT);

    if (status != 0) {
        jclass ex = (*env)->FindClass(env, "java/lang/IllegalArgumentException");
        if (ex != NULL) (*env)->ThrowNew(env, ex, error[0] ? error : "ATRAC3+ encode failed");
        return NULL;
    }
    if (encoded_len > 0x7fffffffU) {
        atracdenc_psp_free(encoded, encoded_len);
        jclass ex = (*env)->FindClass(env, "java/lang/IllegalStateException");
        if (ex != NULL) (*env)->ThrowNew(env, ex, "Encoded output is too large");
        return NULL;
    }

    jbyteArray result = (*env)->NewByteArray(env, (jsize)encoded_len);
    if (result != NULL) {
        (*env)->SetByteArrayRegion(env, result, 0, (jsize)encoded_len, (const jbyte *)encoded);
    }
    atracdenc_psp_free(encoded, encoded_len);
    return result;
}

JNIEXPORT jbyteArray JNICALL
Java_com_olliver_pespspudioeditor_NativeAtrac_encodeWav(JNIEnv *env, jclass clazz,
                                                       jbyteArray input) {
    (void)clazz;
    return encode_wav(env, input, atracdenc_psp192_encode);
}

JNIEXPORT jbyteArray JNICALL
Java_com_olliver_pespspudioeditor_NativeAtrac_encodeWavStereo(JNIEnv *env, jclass clazz,
                                                             jbyteArray input) {
    (void)clazz;
    return encode_wav(env, input, atracdenc_psp280_encode);
}
