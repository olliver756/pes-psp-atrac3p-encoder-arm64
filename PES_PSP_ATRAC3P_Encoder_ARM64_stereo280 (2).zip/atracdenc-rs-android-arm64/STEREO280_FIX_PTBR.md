# Correção do encoder ATRAC3+ estéreo/280 bytes

## Problema

Na segunda passagem de `TonalComponentEncoder`, o código comparava `num_tone_bands` do bloco GHA com `num_quant_units` do espectro. Quando o orçamento de bits reduzia as unidades de quantização após o bloco tonal já ter sido montado, essa comparação podia rejeitar incorretamente o frame com `tonal bands (8) exceed quant units (7)`.

## Alteração

- Removida somente a rejeição no caminho de repetição de `TonalComponentEncoder`.
- Mantido o bloco tonal GHA já montado durante a repetição.
- Substituído o teste que esperava o erro por um teste de regressão com 8 bandas tonais e 7 QUs, verificando que a rotina pede uma nova passagem.
- Não alterados os perfis, o tamanho dos frames, JNI, a classe Java ou o projeto do editor.

## Compilação e validação

O workflow GitHub Actions do repositório compila a biblioteca ARM64 com Rust e Android NDK. Esta cópia contém o código-fonte corrigido; a compilação da `.so` e os testes ainda precisam ser executados no runner. Após isso, testar novamente `ID00055.wav`, verificar frames de 280 bytes e decodificar com FFmpeg. A compilação, sozinha, não comprova compatibilidade com o PES 14 PSP.
