# Experimental PES PSP ATRAC3+ 192-byte mono profile

This source tree adds an opt-in `EncodeBuilder::psp_atrac3plus_192_mono()` setting.
It configures the ATRAC3+ bitstream writer and the RIFF/OMA/RAW output frame size
for 192-byte frames and rejects stereo input when the profile is selected.

## Validation status

- 192-byte frames were observed in the supplied PES PSP mono IDs.
- The profile is experimental. Matching the frame size does not establish bitstream
  compatibility with the PES PSP game or Sony's PSP decoder.
- The encoder processes 2048 PCM samples per channel per frame. At 44.1 kHz and
  192 bytes/frame, the nominal rate is approximately 33.1 kbit/s.
- No Android ARM64 binary is included in this source package. GitHub Actions is
  configured to build one, but a successful workflow run is still required.
- The resulting stream must be independently decoded and tested in a disposable
  copy of an ID and in the game before any integration into the stable app.

## Input constraints

Use 44.1 kHz, 16-bit, mono PCM WAV. No resampling is performed by this API.

## Build

Run `cargo test --workspace --locked` on the build host. The workflow then builds
`libatracdenc.a` for `aarch64-linux-android` and links
`libatrac_encoder.so` with the NDK JNI bridge.
