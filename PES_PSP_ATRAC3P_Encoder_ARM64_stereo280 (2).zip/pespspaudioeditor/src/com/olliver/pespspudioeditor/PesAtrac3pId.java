package com.olliver.pespspudioeditor;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Isolated RIFF/ATRAC3+ ID structure helper.
 * Does not encode audio and is intentionally not wired into MainActivity yet.
 * It only rebuilds IDs after a separately validated encoder supplies compatible frames.
 */
public final class PesAtrac3pId {
    public static final int SAMPLE_RATE = 44100;
    public static final int CHANNELS = 1;
    public static final int FRAME_BYTES = 192;
    public static final int SAMPLES_PER_FRAME = 2048;
    private static final int WAVE_FORMAT_EXTENSIBLE = 0xFFFE;
    private static final byte[] ATRAC3PLUS_GUID = new byte[] {
        (byte)0xBF, (byte)0xAA, 0x23, (byte)0xE9, 0x58, (byte)0xCB, 0x71, 0x44,
        (byte)0xA1, 0x19, (byte)0xFF, (byte)0xFA, 0x01, (byte)0xE4, (byte)0xCE, 0x62
    };

    private PesAtrac3pId() {}

    public static final class Info {
        public final int dataOffset;
        public final int dataLength;
        public final long sampleCount;
        public final int frameCount;
        Info(int dataOffset, int dataLength, long sampleCount) {
            this.dataOffset = dataOffset;
            this.dataLength = dataLength;
            this.sampleCount = sampleCount;
            this.frameCount = dataLength / FRAME_BYTES;
        }
    }

    private static final class Chunk {
        final int headerOffset;
        final int payloadOffset;
        final int length;
        final String id;
        Chunk(int h, int p, int n, String s) { headerOffset=h; payloadOffset=p; length=n; id=s; }
    }

    public static Info inspect(File file) throws IOException {
        return inspect(readAll(file));
    }

    public static Info inspect(byte[] riff) throws IOException {
        Parsed p = parse(riff);
        return new Info(p.data.payloadOffset, p.data.length, readU32(riff, p.fact.payloadOffset));
    }

    /**
     * Replaces only the ATRAC3+ data payload and fact sample count.
     * The caller must supply a real sample count reported by the validated encoder;
     * it must not be guessed from the WAV duration because encoder delay/padding may apply.
     */
    public static void replaceAudio(File originalId, byte[] encodedFrames,
                                    long encodedSampleCount, File outputId) throws IOException {
        if (originalId == null || encodedFrames == null || outputId == null)
            throw new IllegalArgumentException("Arquivo ou áudio nulo.");
        byte[] original = readAll(originalId);
        byte[] rebuilt = replaceAudio(original, encodedFrames, encodedSampleCount);
        File parent = outputId.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs())
            throw new IOException("Não foi possível criar a pasta de saída.");
        FileOutputStream out = new FileOutputStream(outputId);
        try { out.write(rebuilt); out.flush(); } finally { out.close(); }
    }

    public static byte[] replaceAudio(byte[] original, byte[] encodedFrames,
                                      long encodedSampleCount) throws IOException {
        if (encodedFrames == null || encodedFrames.length == 0 || encodedFrames.length % FRAME_BYTES != 0)
            throw new IOException("Áudio codificado inválido: os dados precisam ser múltiplos de 192 bytes.");
        if (encodedSampleCount < 0 || encodedSampleCount > 0xFFFFFFFFL)
            throw new IOException("Quantidade de amostras fora do limite RIFF.");

        Parsed parsed = parse(original);
        ByteArrayOutputStream out = new ByteArrayOutputStream(original.length - parsed.data.length + encodedFrames.length);
        int cursor = 0;
        for (Chunk c : parsed.chunks) {
            if (c == parsed.data) {
                out.write(original, cursor, c.headerOffset - cursor);
                out.write(original, c.headerOffset, 4); // preserve the "data" chunk identifier
                writeU32(out, encodedFrames.length);
                out.write(encodedFrames, 0, encodedFrames.length);
                if ((encodedFrames.length & 1) != 0) out.write(0);
                cursor = c.payloadOffset + c.length + (c.length & 1);
            } else {
                out.write(original, cursor, c.payloadOffset + c.length + (c.length & 1) - cursor);
                cursor = c.payloadOffset + c.length + (c.length & 1);
            }
            if (c == parsed.fact) {
                // Patch fact.dwSampleLength in the output buffer after all preceding bytes.
                byte[] current = out.toByteArray();
                int factOffsetInOutput = c.payloadOffset;
                putU32(current, factOffsetInOutput, encodedSampleCount);
                out.reset();
                out.write(current, 0, current.length);
            }
        }
        if (cursor < original.length) out.write(original, cursor, original.length - cursor);
        byte[] result = out.toByteArray();
        if (result.length < 12) throw new IOException("RIFF resultante inválido.");
        putU32(result, 4, result.length - 8L);
        // The fact chunk's payload offset is unchanged because only the later data chunk changes.
        putU32(result, parsed.fact.payloadOffset, encodedSampleCount);
        return result;
    }

    private static final class Parsed {
        final ArrayList<Chunk> chunks = new ArrayList<Chunk>();
        Chunk fmt, fact, data;
    }

    private static Parsed parse(byte[] b) throws IOException {
        if (b == null || b.length < 20 || !ascii(b,0,"RIFF") || !ascii(b,8,"WAVE"))
            throw new IOException("O arquivo não é um RIFF/WAVE válido.");
        long riffSize = readU32(b,4);
        if (riffSize + 8L > b.length) throw new IOException("Tamanho RIFF maior que o arquivo.");
        Parsed p = new Parsed();
        int pos = 12;
        int end = (int)Math.min(b.length, riffSize + 8L);
        while (pos + 8 <= end) {
            String id = new String(b, pos, 4, "US-ASCII");
            long lenLong = readU32(b, pos + 4);
            if (lenLong > Integer.MAX_VALUE) throw new IOException("Chunk RIFF grande demais.");
            int len = (int)lenLong;
            int payload = pos + 8;
            long nextLong = (long)payload + len + (len & 1);
            if (nextLong > end) throw new IOException("Chunk RIFF truncado: " + id);
            Chunk c = new Chunk(pos, payload, len, id);
            p.chunks.add(c);
            if ("fmt ".equals(id)) p.fmt = c;
            else if ("fact".equals(id)) p.fact = c;
            else if ("data".equals(id)) p.data = c;
            pos = (int)nextLong;
        }
        if (p.fmt == null || p.fact == null || p.data == null)
            throw new IOException("ID sem os chunks fmt, fact ou data.");
        if (p.fmt.length < 40 || p.fact.length < 4)
            throw new IOException("Chunks fmt/fact incompletos.");
        int f = p.fmt.payloadOffset;
        if (readU16(b,f) != WAVE_FORMAT_EXTENSIBLE || readU16(b,f+2) != CHANNELS ||
            readU32(b,f+4) != SAMPLE_RATE || readU16(b,f+12) != FRAME_BYTES ||
            readU16(b,f+16) < 22)
            throw new IOException("O ID não corresponde ao perfil ATRAC3+ mono esperado.");
        for (int i=0; i<ATRAC3PLUS_GUID.length; i++) {
            if (b[f+24+i] != ATRAC3PLUS_GUID[i])
                throw new IOException("GUID do codec diferente de ATRAC3+.");
        }
        if (p.data.length == 0 || p.data.length % FRAME_BYTES != 0)
            throw new IOException("Dados ATRAC3+ originais não estão alinhados em frames de 192 bytes.");
        return p;
    }

    private static byte[] readAll(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream((int)Math.min(f.length(), 1024*1024));
            byte[] buf = new byte[8192]; int n;
            while ((n=in.read(buf)) != -1) out.write(buf,0,n);
            return out.toByteArray();
        } finally { in.close(); }
    }
    private static boolean ascii(byte[] b, int o, String s) {
        if (o+s.length()>b.length) return false;
        for(int i=0;i<s.length();i++) if(b[o+i]!=(byte)s.charAt(i)) return false;
        return true;
    }
    private static int readU16(byte[] b,int o) { return (b[o]&255)|((b[o+1]&255)<<8); }
    private static long readU32(byte[] b,int o) {
        return ((long)b[o]&255)|(((long)b[o+1]&255)<<8)|(((long)b[o+2]&255)<<16)|(((long)b[o+3]&255)<<24);
    }
    private static void writeU32(ByteArrayOutputStream o,long v) {
        o.write((int)v&255); o.write((int)(v>>>8)&255); o.write((int)(v>>>16)&255); o.write((int)(v>>>24)&255);
    }
    private static void putU32(byte[] b,int o,long v) {
        b[o]=(byte)v; b[o+1]=(byte)(v>>>8); b[o+2]=(byte)(v>>>16); b[o+3]=(byte)(v>>>24);
    }
}
