package com.olliver.pespspudioeditor;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import android.media.MediaPlayer;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.util.ArrayList;
import java.util.Locale;
import java.util.HashSet;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends Activity {

    private static final int REQ_OPEN_AUDIO = 1001;
    private static final int REQ_OPEN_FOLDER = 1002;
    private static final int REQ_SAVE_WAV = 1003;
    private static final int REQ_SAVE_WAV_ZIP = 1004;
    private File arquivoExportacaoPendente;
    private HashSet<String> knownUris = new HashSet<String>();
    private LinearLayout fileList;
    private TextView statusText, nowPlaying, durationText, infoText, listTitleView;
    private Button playButton, stopButton;
    private SeekBar progressBar;
    private ArrayList<AudioItem> audioItems = new ArrayList<AudioItem>();
    private MediaPlayer mediaPlayer;
    private Uri currentUri;
    private boolean prepared = false;
    private Handler progressHandler = new Handler(Looper.getMainLooper());
    private Runnable progressRunnable;

    private static class AudioItem {
        Uri uri;
        String name;
        String mime;
        AudioItem(Uri u, String n, String m) { uri=u; name=n; mime=m; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(12));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setBackground(bg(Color.rgb(48,52,59), Color.rgb(83,89,99)));
        return b;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        root.setBackgroundColor(Color.rgb(15,17,21));
        TextView title = text("PES PSP AUDIO EDITOR", 21, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView subtitle = text("PLAYER  •  ATRAC3+  •  WAV", 11, Color.rgb(160,166,175), true);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(28)));

        LinearLayout openActions = new LinearLayout(this);
        openActions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams oa = new LinearLayout.LayoutParams(-1, dp(50));
        oa.topMargin = dp(14);
        root.addView(openActions, oa);

        Button openFiles = button("＋  Abrir arquivos");
        Button openFolder = button("▣  Abrir pasta");
        openActions.addView(openFiles, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout.LayoutParams folderParams = new LinearLayout.LayoutParams(0, -1, 1);
        folderParams.leftMargin = dp(8);
        openActions.addView(openFolder, folderParams);
        openFiles.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openAudio(); }
        });
        openFolder.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openFolder(); }
        });

        LinearLayout exportActions = new LinearLayout(this);
        exportActions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(48));
        ep.topMargin = dp(8);
        root.addView(exportActions, ep);
        Button exportOne = button("Exportar WAV selecionado");
        Button exportAll = button("Exportar todos (ZIP)");
        exportActions.addView(exportOne, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout.LayoutParams ea = new LinearLayout.LayoutParams(0, -1, 1);
        ea.leftMargin = dp(8);
        exportActions.addView(exportAll, ea);
        exportOne.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exportarSelecionado(); }
        });
        exportAll.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exportarTodosZip(); }
        });

        LinearLayout player = new LinearLayout(this);
        player.setOrientation(LinearLayout.VERTICAL);
        player.setPadding(dp(14), dp(14), dp(14), dp(14));
        player.setBackground(bg(Color.rgb(26,29,36), Color.rgb(53,58,68)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(14);
        root.addView(player, pp);

        player.addView(text("REPRODUÇÃO", 12, Color.rgb(79,195,247), true));
        nowPlaying = text("Nenhum áudio selecionado", 17, Color.WHITE, true);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(10);
        player.addView(nowPlaying, np);

        infoText = text("Informações do arquivo aparecerão aqui.", 11, Color.rgb(190,196,205), false);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(8);
        infoText.setVisibility(View.GONE);
        // Informações técnicas ocultas: o painel mostra somente o ID do áudio.

        durationText = text("00:00 / 00:00", 11, Color.rgb(160,166,175), false);
        LinearLayout.LayoutParams dt = new LinearLayout.LayoutParams(-1, -2);
        dt.topMargin = dp(8);
        player.addView(durationText, dt);

        progressBar = new SeekBar(this);
        progressBar.setMax(1000);
        player.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(35)));
        progressBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && mediaPlayer != null && prepared) {
                    mediaPlayer.seekTo((int)(mediaPlayer.getDuration() * (p / 1000.0)));
                }
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        player.addView(controls);
        playButton = button("▶ Reproduzir");
        stopButton = button("■ Parar");
        controls.addView(playButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(46), 1);
        sp.leftMargin = dp(8);
        controls.addView(stopButton, sp);
        playButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { togglePlayback(); }
        });
        stopButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { stopPlayback(); }
        });

        listTitleView = text("ARQUIVOS ABERTOS (0)", 13, Color.rgb(79,195,247), true);
        LinearLayout.LayoutParams lt = new LinearLayout.LayoutParams(-1, dp(38));
        lt.topMargin = dp(18);
        root.addView(listTitleView, lt);

        ScrollView fileScroll = new ScrollView(this);
        fileScroll.setFillViewport(false);
        fileScroll.setVerticalScrollBarEnabled(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            fileScroll.setNestedScrollingEnabled(false);
        }
        LinearLayout.LayoutParams fileScrollParams =
                new LinearLayout.LayoutParams(-1, 0, 1);
        root.addView(fileScroll, fileScrollParams);

        fileList = new LinearLayout(this);
        fileList.setOrientation(LinearLayout.VERTICAL);
        fileScroll.addView(fileList, new ScrollView.LayoutParams(-1, -2));

        statusText = text("Abra um arquivo de áudio para começar.", 12, Color.rgb(160,166,175), false);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(-1, -2);
        st.topMargin = dp(14);
        root.addView(statusText, st);

        setContentView(root);
    }

    private void openAudio() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(Intent.createChooser(intent, "Selecionar um ou vários IDs"), REQ_OPEN_AUDIO);
        } catch (Exception e) {
            statusText.setText("Não foi possível abrir o seletor de arquivos: " + e.getMessage());
        }
    }

    private void openFolder() {
        if (android.os.Build.VERSION.SDK_INT < 21) {
            statusText.setText("A seleção de pastas exige Android 5.0 ou superior.");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQ_OPEN_FOLDER);
        } catch (Exception e) {
            statusText.setText("Não foi possível abrir o seletor de pastas: " + e.getMessage());
        }
    }

    private void addUriToList(Uri uri) {
        if (uri == null) return;
        String key = uri.toString();
        if (knownUris.contains(key)) return;
        knownUris.add(key);
        String name = getDisplayName(uri);
        String mime = getContentResolver().getType(uri);
        AudioItem item = new AudioItem(uri, name, mime == null ? "Tipo não informado" : mime);
        audioItems.add(item);
        addFileRow(item);
        atualizarTituloLista();
    }

    private void scanFolder(final Uri treeUri) {
        statusText.setText("Lendo a pasta e suas subpastas...");
        new AsyncTask<Uri, Void, ArrayList<AudioItem>>() {
            String error = null;
            protected ArrayList<AudioItem> doInBackground(Uri... params) {
                ArrayList<AudioItem> found = new ArrayList<AudioItem>();
                try {
                    scanDocumentTree(params[0], DocumentsContract.getTreeDocumentId(params[0]), found, new HashSet<String>());
                } catch (Exception e) {
                    error = e.getMessage();
                }
                return found;
            }
            protected void onPostExecute(ArrayList<AudioItem> found) {
                int added = 0;
                for (int i = 0; i < found.size(); i++) {
                    AudioItem item = found.get(i);
                    if (!knownUris.contains(item.uri.toString())) {
                        knownUris.add(item.uri.toString());
                        audioItems.add(item);
                        addFileRow(item);
                        added++;
                    }
                }
                atualizarTituloLista();
                String msg = added + " arquivo(s) adicionado(s) da pasta.";
                if (error != null) msg += "\nAviso: " + error;
                if (added == 0 && error == null) msg = "Nenhum arquivo novo encontrado nessa pasta.";
                statusText.setText(msg);
            }
        }.execute(treeUri);
    }

    private void scanDocumentTree(Uri treeUri, String parentDocumentId,
            ArrayList<AudioItem> found, HashSet<String> visited) throws IOException {
        if (parentDocumentId == null || visited.contains(parentDocumentId)) return;
        visited.add(parentDocumentId);

        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId);
        String[] projection = new String[] {
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        };
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(childrenUri, projection, null, null, null);
            if (cursor == null) return;
            while (cursor.moveToNext()) {
                String docId = cursor.getString(0);
                String name = cursor.getString(1);
                String mime = cursor.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    scanDocumentTree(treeUri, docId, found, visited);
                } else {
                    Uri fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                    found.add(new AudioItem(fileUri, name == null ? "arquivo" : name,
                            mime == null ? "Tipo não informado" : mime));
                }
            }
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        if (requestCode == REQ_SAVE_WAV || requestCode == REQ_SAVE_WAV_ZIP) {
            if (arquivoExportacaoPendente == null || data.getData() == null) return;
            Uri destino = data.getData();
            try {
                InputStream in = null;
                java.io.OutputStream out = null;
                try {
                    in = new java.io.FileInputStream(arquivoExportacaoPendente);
                    out = getContentResolver().openOutputStream(destino, "w");
                    if (out == null) throw new IOException("Não foi possível gravar no destino escolhido.");
                    byte[] buffer = new byte[16384]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    out.flush();
                } finally {
                    if (in != null) try { in.close(); } catch (Exception e) {}
                    if (out != null) try { out.close(); } catch (Exception e) {}
                }
                statusText.setText(requestCode == REQ_SAVE_WAV ? "WAV exportado com sucesso." : "Pacote ZIP de WAVs exportado com sucesso.");
            } catch (Exception e) {
                statusText.setText("Falha ao salvar exportação: " + e.getMessage());
            }
            return;
        }

        if (requestCode == REQ_OPEN_AUDIO) {
            int added = 0;
            try {
                if (data.getClipData() != null) {
                    ClipData clips = data.getClipData();
                    for (int i = 0; i < clips.getItemCount(); i++) {
                        Uri uri = clips.getItemAt(i).getUri();
                        try {
                            getContentResolver().takePersistableUriPermission(uri,
                                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } catch (Exception e) {}
                        int before = audioItems.size();
                        addUriToList(uri);
                        if (audioItems.size() > before) added++;
                    }
                } else if (data.getData() != null) {
                    Uri uri = data.getData();
                    try {
                        getContentResolver().takePersistableUriPermission(uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception e) {}
                    int before = audioItems.size();
                    addUriToList(uri);
                    if (audioItems.size() > before) added++;
                }
            } catch (Exception e) {
                statusText.setText("Erro ao adicionar arquivos: " + e.getMessage());
                return;
            }
            statusText.setText(added + " arquivo(s) adicionado(s). Toque em um item para selecionar.");
        } else if (requestCode == REQ_OPEN_FOLDER && data.getData() != null) {
            Uri treeUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(treeUri,
                        data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
            } catch (Exception e) {}
            scanFolder(treeUri);
        }
    }

    private void atualizarTituloLista() {
        if (listTitleView != null) listTitleView.setText("ARQUIVOS ABERTOS (" + audioItems.size() + ")");
    }

    private String getDisplayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (col >= 0) return c.getString(col);
            }
        } catch (Exception e) {
        } finally {
            if (c != null) c.close();
        }
        return uri.getLastPathSegment() == null ? "audio" : uri.getLastPathSegment();
    }

    private void addFileRow(final AudioItem item) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackground(bg(Color.rgb(26,29,36), Color.rgb(53,58,68)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(7);
        fileList.addView(row, rp);
        row.addView(text(item.name, 14, Color.WHITE, true));
        TextView meta = text(item.mime, 10, Color.rgb(160,166,175), false);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.topMargin = dp(3);
        row.addView(meta, mp);
        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { selectAudio(item); }
        });
    }

    private void selectAudio(AudioItem item) {
        stopPlayback();
        currentUri = item.uri;
        nowPlaying.setText(item.name);
        statusText.setText("Selecionado: " + item.name + "\nAnalisando estrutura do arquivo...");
        analisarArquivo(item.uri);
        prepared = false;
        playButton.setText("▶ Reproduzir");
    }


    private int u16(byte[] b, int p) {
        return (b[p] & 255) | ((b[p + 1] & 255) << 8);
    }

    private long u32(byte[] b, int p) {
        return ((long)b[p] & 255) | (((long)b[p + 1] & 255) << 8)
                | (((long)b[p + 2] & 255) << 16) | (((long)b[p + 3] & 255) << 24);
    }

    private String fourCC(byte[] b, int p) {
        return new String(b, p, 4);
    }

    private byte[] readUriBytes(Uri uri) throws IOException {
        InputStream in = null;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            in = getContentResolver().openInputStream(uri);
            if (in == null) throw new IOException("Não foi possível ler o arquivo.");
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toByteArray();
        } finally {
            if (in != null) try { in.close(); } catch (Exception e) {}
            try { out.close(); } catch (Exception e) {}
        }
    }

    private void analisarArquivo(Uri uri) {
        try {
            byte[] b = readUriBytes(uri);
            if (b.length < 12 || !"RIFF".equals(fourCC(b, 0)) || !"WAVE".equals(fourCC(b, 8))) {
                infoText.setText("Formato: arquivo não identificado como RIFF/WAVE\nTamanho: " + b.length + " bytes");
                statusText.setText("Arquivo aberto, mas não corresponde ao cabeçalho RIFF/WAVE esperado.");
                return;
            }

            int canais = -1, bits = -1, alinhamento = -1, fmtExtra = -1;
            long taxa = -1, dataSize = -1, sampleCount = -1;
            int dataOffset = -1;
            boolean atracGuid = false;
            int pos = 12;
            while (pos + 8 <= b.length) {
                String id = fourCC(b, pos);
                long size = u32(b, pos + 4);
                long start = (long)pos + 8;
                if (start + size > b.length) break;
                int chunk = (int)start;
                if ("fmt ".equals(id) && size >= 16) {
                    int tag = u16(b, chunk);
                    canais = u16(b, chunk + 2);
                    taxa = u32(b, chunk + 4);
                    alinhamento = u16(b, chunk + 12);
                    bits = u16(b, chunk + 14);
                    if (size >= 18) fmtExtra = u16(b, chunk + 16);
                    if (tag == 0xFFFE && size >= 40) {
                        byte[] guid = new byte[] {(byte)0xBF,(byte)0xAA,(byte)0x23,(byte)0xE9,
                            (byte)0x58,(byte)0xCB,(byte)0x71,(byte)0x44,(byte)0xA1,(byte)0x19,
                            (byte)0xFF,(byte)0xFA,(byte)0x01,(byte)0xE4,(byte)0xCE,(byte)0x62};
                        atracGuid = true;
                        for (int i = 0; i < 16; i++) if (b[chunk + 24 + i] != guid[i]) atracGuid = false;
                    }
                } else if ("fact".equals(id) && size >= 4) {
                    sampleCount = u32(b, chunk);
                } else if ("data".equals(id)) {
                    dataSize = size;
                    dataOffset = chunk;
                }
                long next = start + size + (size & 1);
                if (next > Integer.MAX_VALUE) break;
                pos = (int)next;
            }

            String codec = atracGuid ? "ATRAC3+ (GUID identificado)" : "Codec não confirmado";
            String quadros = "Não calculado";
            if (dataSize >= 0 && alinhamento > 0) {
                long count = dataSize / alinhamento;
                long resto = dataSize % alinhamento;
                quadros = count + (resto == 0 ? " quadros" : " quadros + " + resto + " bytes restantes");
            }
            long durationMs = (sampleCount > 0 && taxa > 0) ? (sampleCount * 1000L / taxa) : -1;
            infoText.setText("Formato: " + codec
                    + "\nTaxa: " + (taxa > 0 ? taxa + " Hz" : "não identificada")
                    + "\nCanais: " + (canais > 0 ? canais : "não identificado")
                    + "\nBits/campo: " + (bits > 0 ? bits : "não informado pelo arquivo")
                    + "\nExtensão fmt: " + (fmtExtra >= 0 ? fmtExtra + " bytes" : "não informada")
                    + "\nAmostras: " + (sampleCount >= 0 ? sampleCount : "não informado")
                    + "\nAlinhamento: " + (alinhamento > 0 ? alinhamento + " bytes" : "não identificado")
                    + "\nData: " + (dataSize >= 0 ? dataSize + " bytes" : "não encontrado")
                    + "\nOffset data: " + (dataOffset >= 0 ? dataOffset : "não encontrado")
                    + "\nQuadros: " + quadros);
            durationText.setText(durationMs >= 0 ? "00:00 / " + formatTime((int)Math.min(durationMs, Integer.MAX_VALUE)) : "Duração não identificada");
            statusText.setText(atracGuid && dataOffset == 100 && alinhamento == 192
                    ? "Estrutura ATRAC3+ reconhecida. Padrão compatível com os IDs analisados."
                    : "Análise concluída. Confira as informações da estrutura acima.");
        } catch (Exception e) {
            infoText.setText("Não foi possível analisar a estrutura: " + e.getMessage());
            statusText.setText("Falha ao ler o arquivo selecionado.");
        }
    }

    private void togglePlayback() {
        if (currentUri == null) {
            statusText.setText("Primeiro abra e selecione um arquivo.");
            return;
        }
        if (mediaPlayer != null && prepared && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            playButton.setText("▶ Continuar");
            statusText.setText("Reprodução pausada.");
            return;
        }
        if (mediaPlayer != null && prepared) {
            mediaPlayer.start();
            playButton.setText("Ⅱ Pausar");
            statusText.setText("Reprodução retomada.");
            iniciarAtualizacaoProgresso();
            return;
        }
        converterEReproduzir(currentUri);
    }

    private void exportarSelecionado() {
        if (currentUri == null) {
            statusText.setText("Selecione um ID na lista antes de exportar.");
            return;
        }
        final Uri uri = currentUri;
        final String nome = nomeSemExtensao(getDisplayName(uri)) + ".wav";
        statusText.setText("Convertendo o ID selecionado para WAV...");
        new AsyncTask<Void, Void, File>() {
            String erro;
            protected File doInBackground(Void... params) {
                try {
                    File dir = new File(getCacheDir(), "export_wav");
                    if (!dir.exists()) dir.mkdirs();
                    File entrada = new File(dir, "entrada_selecionada.bin");
                    File saida = new File(dir, nome);
                    copiarUri(uri, entrada);
                    converterArquivoParaWav(entrada, saida);
                    return saida;
                } catch (Exception e) { erro = e.getMessage(); return null; }
            }
            protected void onPostExecute(File arquivo) {
                if (arquivo == null) { statusText.setText("Falha ao exportar WAV: " + erro); return; }
                solicitarDestino(arquivo, nome, REQ_SAVE_WAV);
            }
        }.execute();
    }

    private void exportarTodosZip() {
        if (audioItems == null || audioItems.size() == 0) {
            statusText.setText("Nenhum áudio aberto para exportar.");
            return;
        }
        final ArrayList<AudioItem> copia = new ArrayList<AudioItem>(audioItems);
        statusText.setText("Convertendo " + copia.size() + " IDs para WAV e preparando ZIP...");
        new AsyncTask<Void, Void, File>() {
            String erro;
            protected File doInBackground(Void... params) {
                java.util.zip.ZipOutputStream zip = null;
                try {
                    File dir = new File(getCacheDir(), "export_wav_lote");
                    if (!dir.exists()) dir.mkdirs();
                    File pacote = new File(dir, "audios_pes_psp_wav.zip");
                    zip = new java.util.zip.ZipOutputStream(new FileOutputStream(pacote));
                    HashSet<String> nomes = new HashSet<String>();
                    for (int i = 0; i < copia.size(); i++) {
                        AudioItem item = copia.get(i);
                        String nome = nomeSemExtensao(item.name) + ".wav";
                        String nomeUnico = nome;
                        int sufixo = 2;
                        while (nomes.contains(nomeUnico.toLowerCase(Locale.US))) {
                            nomeUnico = nomeSemExtensao(item.name) + "_" + sufixo + ".wav";
                            sufixo++;
                        }
                        nomes.add(nomeUnico.toLowerCase(Locale.US));
                        File entrada = new File(dir, "entrada_" + i + ".bin");
                        File saida = new File(dir, "saida_" + i + ".wav");
                        copiarUri(item.uri, entrada);
                        converterArquivoParaWav(entrada, saida);
                        zip.putNextEntry(new java.util.zip.ZipEntry(nomeUnico));
                        InputStream in = new java.io.FileInputStream(saida);
                        try {
                            byte[] buffer = new byte[16384]; int n;
                            while ((n = in.read(buffer)) != -1) zip.write(buffer, 0, n);
                        } finally { try { in.close(); } catch (Exception e) {} }
                        zip.closeEntry();
                        entrada.delete(); saida.delete();
                    }
                    zip.finish();
                    return pacote;
                } catch (Exception e) { erro = e.getMessage(); return null; }
                finally { if (zip != null) try { zip.close(); } catch (Exception e) {} }
            }
            protected void onPostExecute(File arquivo) {
                if (arquivo == null) { statusText.setText("Falha ao exportar lote: " + erro); return; }
                solicitarDestino(arquivo, "audios_pes_psp_wav.zip", REQ_SAVE_WAV_ZIP);
            }
        }.execute();
    }

    private void solicitarDestino(File arquivo, String nome, int requestCode) {
        arquivoExportacaoPendente = arquivo;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, nome);
        startActivityForResult(intent, requestCode);
    }

    private String nomeSemExtensao(String nome) {
        if (nome == null || nome.trim().length() == 0) return "audio";
        int ponto = nome.lastIndexOf('.');
        if (ponto > 0) nome = nome.substring(0, ponto);
        return nome.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private void converterArquivoParaWav(File entrada, File saida) throws Exception {
        File ffmpeg = new File(getFilesDir(), "ffmpeg");
        if (!ffmpeg.exists() || ffmpeg.length() < 100000) copiarAsset("ffmpeg/ffmpeg", ffmpeg);
        ffmpeg.setExecutable(true, true);
        File libDir = prepararBibliotecasFfmpeg();
        if (libDir == null) throw new IOException("Bibliotecas FFmpeg não encontradas.");
        if (saida.exists()) saida.delete();
        java.util.ArrayList<String> cmd = new java.util.ArrayList<String>();
        cmd.add(ffmpeg.getAbsolutePath()); cmd.add("-y"); cmd.add("-hide_banner");
        cmd.add("-i"); cmd.add(entrada.getAbsolutePath()); cmd.add("-vn");
        cmd.add("-acodec"); cmd.add("pcm_s16le"); cmd.add("-ar"); cmd.add("44100");
        cmd.add("-ac"); cmd.add("1"); cmd.add(saida.getAbsolutePath());
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        java.util.Map<String, String> env = pb.environment();
        env.put("LD_LIBRARY_PATH", libDir.getAbsolutePath() + ":/system/lib64:/vendor/lib64");
        env.put("HOME", getFilesDir().getAbsolutePath());
        env.put("TMPDIR", getCacheDir().getAbsolutePath());
        Process proc = pb.start();
        ByteArrayOutputStream log = new ByteArrayOutputStream();
        InputStream stream = proc.getInputStream();
        try {
            byte[] buffer = new byte[2048]; int n;
            while ((n = stream.read(buffer)) != -1) {
                if (log.size() < 12000) log.write(buffer, 0, Math.min(n, 12000 - log.size()));
            }
        } finally { try { stream.close(); } catch (Exception e) {} }
        int code = proc.waitFor();
        if (code != 0 || !saida.exists() || saida.length() <= 44) {
            throw new IOException("FFmpeg falhou (" + code + "): " + new String(log.toByteArray(), "UTF-8"));
        }
    }

    private void converterEReproduzir(final Uri uri) {
        playButton.setEnabled(false);
        statusText.setText("Preparando FFmpeg e convertendo ATRAC3+ para WAV...");
        new AsyncTask<Void, Void, String>() {
            File wavFile;
            protected String doInBackground(Void... params) {
                try {
                    File ffmpeg = new File(getFilesDir(), "ffmpeg");
                    if (!ffmpeg.exists() || ffmpeg.length() < 100000) {
                        copiarAsset("ffmpeg/ffmpeg", ffmpeg);
                    }
                    if (!ffmpeg.setExecutable(true, true) && !ffmpeg.canExecute()) {
                        return "Não foi possível liberar a execução do FFmpeg.";
                    }

                    File input = new File(getCacheDir(), "audio_atrac_original.bin");
                    copiarUri(uri, input);
                    wavFile = new File(getCacheDir(), "audio_atrac_convertido.wav");
                    if (wavFile.exists()) wavFile.delete();

                    java.util.ArrayList<String> cmd = new java.util.ArrayList<String>();
                    cmd.add(ffmpeg.getAbsolutePath());
                    cmd.add("-y");
                    cmd.add("-hide_banner");
                    cmd.add("-i");
                    cmd.add(input.getAbsolutePath());
                    cmd.add("-vn");
                    cmd.add("-acodec");
                    cmd.add("pcm_s16le");
                    cmd.add("-ar");
                    cmd.add("44100");
                    cmd.add("-ac");
                    cmd.add("1");
                    cmd.add(wavFile.getAbsolutePath());

                    // Copia as bibliotecas nativas para um diretório privado simples.
                    // O linker do processo ffmpeg precisa encontrar todas as dependências
                    // no mesmo diretório do pacote FFmpeg.
                    File libDir = prepararBibliotecasFfmpeg();
                    if (libDir == null) {
                        return "Bibliotecas FFmpeg não encontradas. Verifique se jniLibs/arm64-v8a foi incluída no APK.";
                    }

                    ProcessBuilder pb = new ProcessBuilder(cmd);
                    pb.redirectErrorStream(true);
                    java.util.Map<String, String> env = pb.environment();
                    env.put("LD_LIBRARY_PATH", libDir.getAbsolutePath() + ":/system/lib64:/vendor/lib64");
                    env.put("HOME", getFilesDir().getAbsolutePath());
                    env.put("TMPDIR", getCacheDir().getAbsolutePath());
                    Process proc = pb.start();

                    ByteArrayOutputStream logOut = new ByteArrayOutputStream();
                    InputStream log = proc.getInputStream();
                    byte[] buf = new byte[2048];
                    int read;
                    while ((read = log.read(buf)) != -1) {
                        if (logOut.size() < 12000) {
                            int keep = Math.min(read, 12000 - logOut.size());
                            logOut.write(buf, 0, keep);
                        }
                    }
                    int code = proc.waitFor();
                    String ffLog = new String(logOut.toByteArray(), "UTF-8").trim();
                    if (code != 0 || !wavFile.exists() || wavFile.length() <= 44) {
                        if (ffLog.length() == 0) ffLog = "O FFmpeg não retornou mensagem. Verifique permissões e carregamento das bibliotecas.";
                        return "Falha FFmpeg (código " + code + ").\\n" + ffLog;
                    }
                    return null;
                } catch (Exception e) {
                    return "Falha ao executar FFmpeg: " + e.getMessage();
                }
            }
            protected void onPostExecute(String error) {
                playButton.setEnabled(true);
                if (error != null) {
                    statusText.setText(error);
                    return;
                }
                iniciarWav(wavFile);
            }
        }.execute();
    }


    private File prepararBibliotecasFfmpeg() throws IOException {
        String[] nomes = new String[] {
            "libavdevice.so", "libavfilter.so", "libavformat.so",
            "libavcodec.so", "libswresample.so", "libswscale.so",
            "libavutil.so", "libc++_shared.so"
        };
        File destino = new File(getFilesDir(), "ffmpeg-libs");
        if (!destino.exists() && !destino.mkdirs()) {
            throw new IOException("Não foi possível criar " + destino.getAbsolutePath());
        }

        // Algumas versões do ApkBuilder empacotam jniLibs no APK, mas não
        // deixam todos os arquivos visíveis em nativeLibraryDir. Tentamos
        // primeiro o diretório nativo e depois lemos diretamente o APK.
        File origem = new File(getApplicationInfo().nativeLibraryDir);
        String apkPath = getApplicationInfo().sourceDir;
        java.util.zip.ZipFile apk = null;
        try {
            apk = new java.util.zip.ZipFile(apkPath);
            for (int i = 0; i < nomes.length; i++) {
                String nome = nomes[i];
                File dst = new File(destino, nome);
                File srcLib = new File(origem, nome);
                boolean copiado = false;

                if (srcLib.isFile() && srcLib.length() > 0) {
                    copiarArquivo(srcLib, dst);
                    copiado = true;
                } else {
                    java.util.zip.ZipEntry entry = apk.getEntry("lib/arm64-v8a/" + nome);
                    if (entry != null && entry.getSize() > 0) {
                        InputStream in = apk.getInputStream(entry);
                        FileOutputStream out = new FileOutputStream(dst);
                        try {
                            byte[] buffer = new byte[16384];
                            int n;
                            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                            out.flush();
                        } finally {
                            try { in.close(); } catch (Exception e) {}
                            try { out.close(); } catch (Exception e) {}
                        }
                        copiado = dst.isFile() && dst.length() > 0;
                    }
                }

                if (!copiado) {
                    throw new IOException("Biblioteca ausente no APK: " + nome
                        + " | nativeLibraryDir=" + origem.getAbsolutePath());
                }
                dst.setReadable(true, true);
            }
        } finally {
            if (apk != null) try { apk.close(); } catch (Exception e) {}
        }
        return destino;
    }

    private void copiarArquivo(File origem, File destino) throws IOException {
        InputStream in = new java.io.FileInputStream(origem);
        FileOutputStream out = new FileOutputStream(destino);
        try {
            byte[] buffer = new byte[16384];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.flush();
        } finally {
            try { in.close(); } catch (Exception e) {}
            try { out.close(); } catch (Exception e) {}
        }
    }

    private void copiarAsset(String assetName, File destino) throws IOException {
        InputStream in = getAssets().open(assetName);
        FileOutputStream out = new FileOutputStream(destino);
        try {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.flush();
        } finally {
            try { in.close(); } catch (Exception e) {}
            try { out.close(); } catch (Exception e) {}
        }
        destino.setReadable(true, true);
        destino.setExecutable(true, true);
    }

    private void copiarUri(Uri uri, File destino) throws IOException {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new IOException("Não foi possível abrir o ID selecionado.");
        FileOutputStream out = new FileOutputStream(destino);
        try {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            out.flush();
        } finally {
            try { in.close(); } catch (Exception e) {}
            try { out.close(); } catch (Exception e) {}
        }
    }

    private void iniciarWav(File wavFile) {
        try {
            releasePlayer();
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(wavFile.getAbsolutePath());
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer mp) {
                    prepared = true;
                    mp.start();
                    playButton.setText("Ⅱ Pausar");
                    durationText.setText("00:00 / " + formatTime(mp.getDuration()));
                    progressBar.setProgress(0);
                    iniciarAtualizacaoProgresso();
                    statusText.setText("ATRAC3+ convertido para WAV. Reprodução iniciada.");
                }
            });
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer mp) {
                    pararAtualizacaoProgresso();
                    playButton.setText("▶ Reproduzir");
                    if (progressBar != null) progressBar.setProgress(1000);
                    if (durationText != null) durationText.setText(formatTime(mp.getDuration()) + " / " + formatTime(mp.getDuration()));
                    tocarProximoAudio();
                }
            });
            mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    statusText.setText("O WAV foi gerado, mas o player não conseguiu reproduzi-lo.");
                    releasePlayer();
                    return true;
                }
            });
            mediaPlayer.prepareAsync();
            statusText.setText("WAV gerado. Preparando reprodução...");
        } catch (Exception e) {
            statusText.setText("WAV gerado, mas houve erro ao abrir: " + e.getMessage());
            releasePlayer();
        }
    }

    private void tocarProximoAudio() {
        if (currentUri == null || audioItems == null || audioItems.size() < 2) {
            statusText.setText("Reprodução concluída.");
            return;
        }

        int indiceAtual = -1;
        for (int i = 0; i < audioItems.size(); i++) {
            if (currentUri.equals(audioItems.get(i).uri)) {
                indiceAtual = i;
                break;
            }
        }

        if (indiceAtual < 0 || indiceAtual + 1 >= audioItems.size()) {
            statusText.setText("Fim da lista. Reprodução concluída.");
            return;
        }

        AudioItem proximo = audioItems.get(indiceAtual + 1);
        currentUri = proximo.uri;
        nowPlaying.setText(proximo.name);
        playButton.setText("▶ Reproduzir");
        if (progressBar != null) progressBar.setProgress(0);
        if (durationText != null) durationText.setText("00:00 / 00:00");
        statusText.setText("Próximo áudio: " + proximo.name);
        analisarArquivo(proximo.uri);
        prepared = false;
        converterEReproduzir(proximo.uri);
    }

    private void stopPlayback() {
        pararAtualizacaoProgresso();
        releasePlayer();
        if (playButton != null) playButton.setText("▶ Reproduzir");
        if (progressBar != null) progressBar.setProgress(0);
    }

    private void releasePlayer() {
        pararAtualizacaoProgresso();
        if (mediaPlayer != null) {
            try { mediaPlayer.stop(); } catch (Exception e) {}
            try { mediaPlayer.release(); } catch (Exception e) {}
            mediaPlayer = null;
        }
        prepared = false;
    }

    private void iniciarAtualizacaoProgresso() {
        pararAtualizacaoProgresso();
        progressRunnable = new Runnable() {
            public void run() {
                if (mediaPlayer != null && prepared) {
                    try {
                        int duracao = mediaPlayer.getDuration();
                        int posicao = mediaPlayer.getCurrentPosition();
                        if (duracao > 0) {
                            int progresso = (int)((posicao * 1000L) / duracao);
                            if (progressBar != null && !progressBar.isPressed()) {
                                progressBar.setProgress(Math.max(0, Math.min(1000, progresso)));
                            }
                            if (durationText != null) {
                                durationText.setText(formatTime(posicao) + " / " + formatTime(duracao));
                            }
                        }
                        if (mediaPlayer.isPlaying()) progressHandler.postDelayed(this, 200);
                    } catch (IllegalStateException e) { }
                }
            }
        };
        progressHandler.post(progressRunnable);
    }

    private void pararAtualizacaoProgresso() {
        if (progressRunnable != null) {
            progressHandler.removeCallbacks(progressRunnable);
            progressRunnable = null;
        }
    }

    private String formatTime(int ms) {
        int sec = ms / 1000;
        return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60);
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
